import pygame
import sys

# Initialize Pygame
# pygame.init()

def sel(opt3,exp,hel,att):

     # Loop indefinitely
    # Set window size
    ex=exp
    window_size = (930, 650)
    screen = pygame.display.set_mode(window_size)
    pygame.display.set_caption("Select Page")

    # Load background image
    background_image = pygame.image.load("select page.png").convert()

    # Set font
    font = pygame.font.Font("KNIGHT WARRIOR.otf", 36)
    font2 = pygame.font.Font("KNIGHT WARRIOR.otf", 34)
    text_color = (255, 255, 255)
    hover_color = (125, 125, 125)
    hover_color2 = (150,0, 0)

    # Render text
    text = font.render("Health                       "+str(hel), True, text_color)
    text_rect = text.get_rect()
    text_rect.topleft = (80, 65)

    text1 = font.render("Attack                       "+str(att), True, text_color)
    text1_rect = text1.get_rect()
    text1_rect.topleft = (80, 175)

    text2 = font.render(opt3, True, text_color)
    text2_rect = text2.get_rect()
    text2_rect.topleft = (80, 285)


    tex_do=0

    # Define button properties
    button_font = pygame.font.Font(None, 45)
    button_color = (75, 75, 75)
    button_hover_color = (75, 75, 75)
    button_width = 100
    button_height = 50

    # Function to create buttons
    def create_button(text, position, action,butp1,butp2,butp3,but1,but2,but3,confirm_box,ex):
        # global but1,but2,but3,but4,butp1,butp2,butp3,butp4,confirm_box
        ext=ex
        button = pygame.Rect(position[0], position[1], button_width, button_height)
        pygame.draw.rect(screen, button_color, button)
        text_surface = button_font.render(text, True, text_color)
        text_rect = text_surface.get_rect(center=button.center)
        if text_rect.collidepoint(mouse_pos):
            text_surface = font.render(text, True, hover_color)
        else:
            text_surface = font.render(text, True, text_color)
        screen.blit(text_surface, text_rect)
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if (text_rect.collidepoint(mouse_pos) and butp1==True):
                    but1=True
                    butp1=False
                    confirm_box=False
                    ext-=1
                elif (text_rect.collidepoint(mouse_pos) and butp2==True):
                    but2=True
                    butp2=False
                    confirm_box=False
                    ext-=1
                elif (text_rect.collidepoint(mouse_pos) and butp3==True):
                    but3=True
                    butp3=False
                    confirm_box=False
                    ext-=1
                else:
                    confirm_box=False
                    butp1=False
                    butp2=False
                    butp3=False
        return button,butp1,butp2,butp3,but1,but2,but3,confirm_box,ext

    def create_button1(text, position, action):
        # global but1,but2,but3,but4,butp1,butp2,butp3,butp4
        button = pygame.Rect(position[0], position[1], button_width, button_height)
        pygame.draw.rect(screen, button_color, button)
        text_surface = button_font.render(text, True, text_color)
        text_rect = text_surface.get_rect(center=button.center)
        if text_rect.collidepoint(mouse_pos):
            text_surface = font.render(text, True, hover_color)
        else:
            text_surface = font.render(text, True, text_color)
        screen.blit(text_surface, text_rect)
        return button

    def create_button2(text, position, action):
        # global but1,but2,but3,but4,butp1,butp2,butp3,butp4
        button = pygame.Rect(position[0], position[1], 110, 60)
        pygame.draw.rect(screen, button_color, button)
        text_surface = button_font.render(text, True, text_color)
        text_rect = text_surface.get_rect(center=(790,575))
        if text_rect.collidepoint(mouse_pos):
            text_surface = font2.render(text, True, hover_color2)
        else:
            text_surface = font2.render(text, True, text_color)
        screen.blit(text_surface, text_rect)
        return button,text_rect
    
    # Main loop
    running = True
    confirm_box=False
    but1=False
    but2=False
    but3=False
    butp1=False
    butp2=False
    butp3=False
    nhel=hel
    natt=att
    flag=False
    while running:
        # Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                if (text_rect.collidepoint(mouse_pos) and but1==False and ex>0):
                    # Display confirmation box
                    confirm_box = True
                    butp1=True
                elif (text1_rect.collidepoint(mouse_pos) and but2==False and ex>0):
                    # Display confirmation box
                    confirm_box = True
                    butp2=True
                elif (text2_rect.collidepoint(mouse_pos) and but3==False and ex>0):
                    # Display confirmation box
                    confirm_box = True
                    butp3=True
                elif (text_do.collidepoint(mouse_pos)):
                    return [flag,nhel,natt]
        
        # Clear the screen
        screen.blit(background_image, (0, 0))
        
        # Check if mouse is hovering over text
        mouse_pos = pygame.mouse.get_pos()
        if text_rect.collidepoint(mouse_pos):
            text = font.render("Health                       "+str(hel), True, hover_color)
        else:
            text = font.render("Health                       "+str(hel), True, text_color)
        
        if text1_rect.collidepoint(mouse_pos):
            text1 = font.render("Attack                       "+str(att), True, hover_color)
        else:
            text1 = font.render("Attack                       "+str(att), True, text_color)

        if text2_rect.collidepoint(mouse_pos):
            text2 = font.render(opt3, True, hover_color)
        else:
            text2 = font.render(opt3, True, text_color)
            
        if but1==True:
            nhel=hel+500
            text = font.render("Health                     "+str(hel+500), True, (125,0,0))
        if but2==True:
            natt=att+50
            text1 = font.render("Attack                      "+str(att+50), True, (125,0,0))
        if but3==True:
            flag=True
            text2 = font.render(opt3, True, (125,0,0))

        text4 = font.render("Exp points : " + str(ex), True, (185, 185, 185))
        text4_rect = text4.get_rect()
        text4_rect.topleft = (675, 50)
        # Draw text on the screen
        screen.blit(text, text_rect)
        screen.blit(text1, text1_rect)
        screen.blit(text2, text2_rect)
        screen.blit(text4, text4_rect)

        if confirm_box:
            confirm_box_rect = pygame.Rect(700, 200, 200, 250)
            pygame.draw.rect(screen, (75, 75, 75), confirm_box_rect)
            
            # Render "confirm?" heading
            confirm_heading = font.render("Confirm?", True, text_color)
            confirm_heading_rect = confirm_heading.get_rect(center=(800, 250))
            screen.blit(confirm_heading, confirm_heading_rect)
            
            # Create "Yes" and "No" buttons
            yes_button,butp1,butp2,butp3,but1,but2,but3,confirm_box,ex = create_button("Yes", (730, 290), "yes",butp1,butp2,butp3,but1,but2,but3,confirm_box,ex)
            print(ex)
            no_button= create_button1("No", (730, 360), "no")

        done,text_do=create_button2("Done",(730,550),"done")
        # Update the display
        pygame.display.flip()

#     # Quit Pygame
# sel("Ability",3,100,100)
# pygame.quit()
# sys.exit()

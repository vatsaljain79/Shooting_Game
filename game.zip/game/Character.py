import pygame,random

WIDTH, HEIGHT = 800, 600
GROUND=HEIGHT-180

class Character:
    
    def __init__(self,screen,x,WASD=False,speed=0,state='right',name=None,computer=None,health=100,attack=20,player=False,bullet=False,attack_freq=3):
        self.char_x=x
        self.spritesheet = pygame.image.load("Walk.png")
        self.flipped_sprite_image = pygame.transform.flip(self.spritesheet, True, False)
        self.spritesheet1 = pygame.image.load("Jump.png")
        self.spritesheet2 = pygame.image.load("Idle_2.png")
        self.spritesheet3= pygame.transform.flip(self.spritesheet2, True, False)
        self.spritesheet4 = pygame.image.load("Attack_1.png")
        self.spritesheet5=[]
        self.spritesheet6=[]
        self.spritesheet7=[]
        # print(spritesheet4.get_height(),spritesheet4.get_width())self.
        # Define character properties
        self.FRAME_WIDTH, self.FRAME_HEIGHT = 128, 128
        self.frame_count = 0
        self.animation_frames = [self.spritesheet.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT))
                            for x in range(self.spritesheet.get_width() // self.FRAME_WIDTH)]
        self.animation_frames1 = [self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT))
                            for x in range(self.spritesheet.get_width() // self.FRAME_WIDTH)]
        self.animation_frames2 = [self.spritesheet2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT))
                            for x in range(self.spritesheet.get_width() // self.FRAME_WIDTH)]
        self.animation_frames3 = [self.spritesheet3.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT))
                            for x in range(self.spritesheet.get_width() // self.FRAME_WIDTH)]
        self.animation_frames4 = [self.spritesheet4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT))
                   for x in range(self.spritesheet4.get_width() // self.FRAME_WIDTH)]
        self.animation_frames5=self.animation_frames4
        self.animation_frames6=self.animation_frames4
        self.animation_frames7=self.animation_frames4
        self.animation_frames8=self.animation_frames4
        self.animation_frames9=self.animation_frames4
        self.animation_frames10=self.animation_frames4
        self.animation_frames11=self.animation_frames4
        self.speed=speed
        self.SPEED=speed
        # self.char_x=0
        self.state=state
        self.frame_count1=0
        self.offset=70
        self.WASD=WASD
        self.SCREEN=screen
        self.HEIGHT=600
        self.WIDTH=800
        self.f=0
        self.g=0
        self.background_state='right'
        self.dir=None
        if 'right' in self.state:
            self.dir='right'
        elif 'left' in self.state:
            self.dir='left'
        self.offset_speed=30
        self.gravity=5
        self.health=health
        self.MAX_HEALTH=health
        self.exist=True
        self.name=name
        self.computer=computer
        self.attack=attack
        self.player=player
        self.health_decrement=0
        self.health_timer=0
        self.healthy=0
        self.attack_e=300
        self.actual_x=0
        self.actual_x0=2500
        self.bullet=bullet
        self.attack_freq=attack_freq
        self.speed_x=0
        self.HEALTH=health
        self.name1=self.name

    def collision(self,other):
        # print(abs(self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)))
        c=self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)
        if (abs(self.offset-other.offset)<=60 and abs(c)<=60):
            if 'attack' in self.state and (other.exist) and ((self.dir=='right' and c<0)or (self.dir=='left' and c>0)):
                other.health-=self.attack
                other.health_decrement+=self.attack
                # print(other.name,other.health_decrement)
                if other.health<=0:
                    self.computer=None

    def state_control(self):
        keys = pygame.key.get_pressed()
        if not 'dead' in self.state:
            if not self.WASD:
                if keys[pygame.K_RIGHT]:  # Right arrow key held down
                    if self.player:
                        if (self.state!='right' and 'up' not in self.state): self.frame_count=0; self.speed_x=0;self.g=1;self.speed=0 # Right arrow key held down
                    else:
                        if (self.state!='right'): self.frame_count=0
                    self.frame_count += 1
                    self.frame_count1=0
                    self.state='right'
                    self.background_state='right'
                    self.dir='right'
                    self.char_x+=self.speed
                    
                        
                    # self.actual_x+=self.speed
                    # print(self.char_x,self.speed)
                    # print("by")
                elif keys[pygame.K_LEFT]:
                    if self.player:
                        if (self.state!='left' and 'up' not in self.state): self.frame_count=0;self.speed_x=0;self.g=1;self.speed=0
                    else:
                        if (self.state!='left'): self.frame_count=0
                    self.frame_count += 1
                    self.state='left'
                    self.frame_count1=0
                    self.char_x-=self.speed
                    self.background_state='left'
                    self.dir='left'
                    # self.actual_x-=self.speed
                    # print('bye')
                elif keys[pygame.K_DOWN]:
                    if('duck' not in self.state):self.frame_count1=0
                    self.frame_count=0
                    self.state='duck-'+self.dir
                    self.background_state='duck'
                    
                elif self.state=='right':
                    self.state='idle_right'
                    self.dir='right'
                    self.background_state='idle_right'
                elif self.state=='left':
                    self.state='idle_left'
                    self.background_state='idle_left'
                    self.dir='left'
                if keys[pygame.K_UP]:
                    self.state='up-'+self.dir
                    # print(self.char_x)
                    if self.f==0:
                        self.frame_count =0
                        self.frame_count1=0
                        # self.state='up-'
                        self.f+=1
                        # self.offset-=40
                        
                if keys[pygame.K_SPACE]:
                    if('attack' not in self.state):self.frame_count1=0
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'
            elif self.computer!=None:
                other=self.computer
                c=self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)
                
                if abs(c)>=55:
                    if 'attack' not in self.state:
                        if c<0:
                            if abs(c)<=self.attack_e:
                                if (self.state!='right'): self.frame_count=0 # Right arrow key held down
                                self.frame_count += 1
                                self.frame_count1=0
                                self.state='right'
                                self.background_state='right'
                                self.dir='right'
                                self.char_x+=self.speed
                            else:
                                self.dir='right'
                                self.state='idle_right'
                        else:
                            if abs(c)<=self.attack_e:
                                if (self.state!='left'): self.frame_count=0
                                self.frame_count += 1
                                self.state='left'
                                self.frame_count1=0
                                self.char_x-=self.speed
                                self.background_state='left'
                                self.dir='left'
                            else:
                                self.dir='left'
                                self.state='idle_left'

                        
                elif 'attack' not in self.state and 'dead' not in self.state:
                    self.frame_count1=0
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'
                
                # if self.state=='right':
                #     self.state='idle_right'
                #     self.dir='right'
                #     self.background_state='idle_right'
                # elif self.state=='left':
                #     self.state='idle_left'
                #     self.background_state='idle_left'
                #     self.dir='left'

                
            else:
                if keys[pygame.K_d]:  # Right arrow key held down
                    if (self.state!='right'): self.frame_count=0 # Right arrow key held down
                    self.frame_count += 1
                    self.frame_count1=0
                    self.state='right'
                    self.background_state='right'
                    self.dir='right'
                    self.char_x+=self.speed
                    # self.actual_x+=self.SPEED
                    # print(self.char_x,self.speed)
                    # print("by")
                elif keys[pygame.K_a]:
                    if (self.state!='left'): self.frame_count=0
                    self.frame_count += 1
                    self.state='left'
                    self.frame_count1=0
                    self.char_x-=self.speed
                    self.background_state='left'
                    self.dir='left'
                    # self.actual_x-=self.SPEED
                    
                elif self.state=='right':
                    self.state='idle_right'
                    self.dir='right'
                    self.background_state='idle_right'
                elif self.state=='left':
                    self.state='idle_left'
                    self.background_state='idle_left'
                    self.dir='left'
                if keys[pygame.K_w]:
                    self.state='up-'+self.dir
                    # print(self.char_x)
                    if self.f==0:
                        self.frame_count =0
                        self.frame_count1=0
                        # self.state='up-'
                        self.f+=1
                        # self.offset-=40
                        
                elif keys[pygame.K_x]:
                    self.frame_count1=0
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'
                
                
                
            
        if(self.f!=0):
             self.offset-=self.offset_speed
             self.offset_speed-=self.gravity
             self.f+=1
             
             if(self.f==14):
                 self.f=0
                 if (not keys[pygame.K_RIGHT] and not keys[pygame.K_LEFT]):
                    self.state='idle_'+self.dir
                    self.background_state=self.state
                 self.offset_speed=30
                #  print(self.state,self.f)
                    # print("hi")
        if(self.g!=0 and ('idle' not in self.state) and self.player):
             self.speed_x+=1
             self.g+=1
             print(self.speed_x,self.SPEED,self.g)
             if(self.speed_x>=self.SPEED):
                 self.speed_x=self.SPEED
                 self.g=0

        if ('attack' in self.state) and self.frame_count1>len(self.animation_frames4):
            self.state='idle_'+self.dir
            self.background_state=self.state
            self.frame_count1=0

        if ('duck' in self.state) and self.frame_count1>len(self.animation_frames10):
            self.state='idle_'+self.dir
            self.background_state=self.state
            self.frame_count1=0

        if ('dead' in self.state):
            self.frame_count1=min(len(self.animation_frames9)-1,self.frame_count1)
            if self.frame_count1==len(self.animation_frames9)-1:
                self.computer=None
                self.exist=False
        if self.health<=0:
            if 'dead' not in self.state:
                self.frame_count1=0
            self.state='dead-'+self.dir
            self.background_state=self.state
            # print(3)
            
            # print(self.state)
        if self.health_decrement>0:
            self.health_timer+=1
            self.healthy+=5
            if self.health_timer==20:
                self.health_decrement=0
                self.health_timer=0
                self.healthy=0
        if self.player:
            pass
            self.char_x=min(max(0,self.char_x),875)
            # self.actual_x=max(0,self.actual_x)
            # if self.actual_x==0:
            #     self.char_x=0
        # if self.player:
        #     print(self.actual_x,'hi',self.char_x)

    def health_bar(self):
         if self.health>=0:
                text_surface = pygame.font.Font('freesansbold.ttf',20).render(self.name1, True, (0,0,0))
                text_rect = text_surface.get_rect(center=(self.char_x+28, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-40))  # Center text on screen
                self.SCREEN.blit(text_surface, text_rect)
                if self.health_decrement>0:
                    text_surface = pygame.font.Font('freesansbold.ttf',20).render(str(self.health_decrement), True, (255,0,0))
                    text_rect = text_surface.get_rect(center=(self.char_x+28, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20-self.healthy))  # Center text on screen
                    self.SCREEN.blit(text_surface, text_rect)
                pygame.draw.rect(self.SCREEN, (0,0,0), (self.char_x+14, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-22, 34, 14))
                
                pygame.draw.rect(self.SCREEN, (0,255,0), (self.char_x+16, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20, (30/self.MAX_HEALTH)*self.health, 10))
                

        
    def draw(self):
        self.state_control()
        
        if self.exist:   

            if self.state=='left':
                self.SCREEN.blit(self.animation_frames1[self.frame_count % len(self.animation_frames1)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset))
            elif self.state=='right':
                self.SCREEN.blit(self.animation_frames[self.frame_count % len(self.animation_frames)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset))
            elif self.state=='attack-right':
                self.SCREEN.blit(self.animation_frames4[self.frame_count1 % len(self.animation_frames4)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset))
            elif self.state=='attack-left':
                self.SCREEN.blit(self.animation_frames7[self.frame_count1 % len(self.animation_frames7)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset))
            elif self.state=='idle_right':
                if self.name=='BOSS':
                    print(1,self.char_x)
                self.SCREEN.blit(self.animation_frames2[self.frame_count1 % len(self.animation_frames2)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset))
            elif self.state=='dead-right':
                self.SCREEN.blit(self.animation_frames8[self.frame_count1 % len(self.animation_frames8)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset))
            elif self.state=='dead-left':
                self.SCREEN.blit(self.animation_frames9[self.frame_count1 % len(self.animation_frames9)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset))
            elif self.state=='duck-right':
                self.SCREEN.blit(self.animation_frames10[self.frame_count1 % len(self.animation_frames10)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset))
            elif self.state=='duck-left':
                self.SCREEN.blit(self.animation_frames11[self.frame_count1 % len(self.animation_frames11)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset))
            
            elif self.state=='idle_left':
                self.SCREEN.blit(self.animation_frames3[self.frame_count1 % len(self.animation_frames3)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset))
            elif self.state=='up-right':
                self.SCREEN.blit(self.animation_frames5[self.frame_count1 % len(self.animation_frames5)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset))
            elif self.state=='up-left':
                self.SCREEN.blit(self.animation_frames6[self.frame_count1 % len(self.animation_frames6)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset))

            self.health_bar()
           
    def get_background(self,back_speed,background_x=0):
        background_speed=0
        if self.background_state=='right':
            if self.char_x>=350 and self.actual_x0>1000:
                background_speed=self.speed_x
                self.speed=0
                
            else:
                self.speed=self.speed_x
                background_speed=0
            background_x-=background_speed
            self.actual_x-=background_speed
            self.actual_x0-=background_speed
            #if background_x<=-930:
                #background_x=0
        elif self.background_state=='left':
            # pass
            if self.char_x<=350 and background_x<0:
                self.speed=0
                background_speed=-self.speed_x
            else:
                
                self.speed=self.speed_x
                background_speed=0
            background_x-=background_speed
            self.actual_x-=background_speed
            self.actual_x0-=background_speed
            background_x=min(0,background_x)
            #if background_x>=930:
                #background_x=0
        # print(background_x,'hihihii')
        return background_x,background_speed
    
    def frequency_manager(self,p,attack_freq,attackers):
        if 'attack' in self.state:
            if p%self.attack_freq==0:
                self.frame_count1+=1
                
                if self.frame_count1==3:
                    for attacker in attackers:
                        self.collision(attacker)
                    # self.collision(P4)
        elif p%3==0:
            self.frame_count1+=1
        if len(attackers)==0:
            self.computer=None



        


class Hobbit(Character):
    def __init__(self,screen,x,WASD=False,speed=0,state='right',name=None,computer=None,health=100,attack=20,player=False,bullet=False,attack_freq=3,new_factor=64,summit=False):
        Character.__init__(self,screen,x,WASD,speed,state,name,computer,health,attack,player,bullet,attack_freq)
        if summit:
            self.spritesheet = pygame.image.load("hobbit_black.png")
        else:
            self.spritesheet = pygame.image.load("hobbit.png")
        self.flipped_sprite_image = pygame.transform.flip(self.spritesheet, True, False)
        self.FRAME_WIDTH, self.FRAME_HEIGHT = 32, 32
        #new_factor=64 #96
        self.animation_frames = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 96, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(8)]
        self.animation_frames1 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 96, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(8)]
        self.animation_frames2 = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(2)]
        self.animation_frames3 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH+192, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(2)]
        self.animation_frames4 = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 256, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(8)]
        self.animation_frames5 = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 160, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(8)]
        self.animation_frames6 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 160, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(8)]
        self.animation_frames7 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 256, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(7,-1,-1)]
        self.animation_frames8 = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 224, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(8)]
        self.animation_frames9 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 224, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(7,-1,-1)]
        self.animation_frames10 = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 128, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(6)]
        self.animation_frames11 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((64+ x * self.FRAME_WIDTH, 128, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(5,-1,-1)]
        self.offset=84 +10 + 110#+120+20
        self.FRAME_WIDTH, self.FRAME_HEIGHT = new_factor, new_factor

    
class Bullet:
    def __init__(self,SCREEN,image,x,y,speed=0,attack=0,dir='right',range=(20,20),player=False,angle=False):
        self.bullet = pygame.image.load(image)
        self.angle=angle
        if self.angle:
            self.bullet=pygame.transform.flip(self.bullet, True, False)
            self.bullet=pygame.transform.scale(self.bullet,(100,100))
        
        self.FRAME_WIDTH=self.bullet.get_width()
        self.FRAME_HEIGHT=self.bullet.get_height()
        self.flip= pygame.transform.flip(self.bullet, True, False)
        self.speed=speed
        self.attack=attack
        self.SCREEN=SCREEN
        self.dir=dir
        self.state='ready'
        self.x=x
        self.y=y
        self.exist=True
        self.image=image
        self.range=range
        self.player=player
        if self.player:
            self.range=(45,60)
        

        

    def draw(self):
            if self.exist:
                if self.dir=='right':
                    self.x+=self.speed
                    self.SCREEN.blit(self.bullet,(self.x,self.y))
                else:
                    if self.angle:
                        self.y+=self.speed
                        # print(self.y)
                        if self.y>=460:
                            self.exist=False
                    self.x-=self.speed
                    self.SCREEN.blit(self.flip,(self.x,self.y))
                
    def collision(self,other):
        # print(abs(self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)))
        
        c=self.x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)
        if other.name=='BOSS':
            print(abs(self.y+(self.FRAME_HEIGHT//2)-(other.HEIGHT // 2)-other.offset),'hello',self.range[0])
        # print(abs(c),'hi')
        # print(other.name,self.player,self.range)
        if (abs(self.y+(self.FRAME_HEIGHT//2)-(other.HEIGHT // 2)-other.offset)<=self.range[0] and abs(c)<=self.range[1]):
            
            # print("BYEYEYE")

            if self.exist and (other.exist and ((self.player and not other.player) or (not self.player and other.player and ((other.name=='BOSS' and True) or (other.name!='BOSS' and 'duck' not in other.state)))) ):
                c=random.randint(0,2)
                print("HIHIHIIHIHI")
                
                
                if other.name=='BOSS' and c==2 and not other.player:
                    other.state='up-'+other.dir
                    # print(self.char_x)
                    if other.f==0:
                        other.frame_count =0
                        other.frame_count1=0
                        # self.state='up-'
                        other.f+=1
                elif other.name=='TeleBoss' and c==2:
                    if self.dir=='right':
                        self.dir='left'
                    else:
                        self.dir='right'
                    self.player=False
                    self.range=(20,30)
                    self.exist=False
                    other.bullets.append(Bullet(self.SCREEN,"goli.png",self.x,self.y,speed=self.speed,attack=self.attack,dir=self.dir,range=(20,30),player=False))

                elif other.name=='DarkFairy' and c==2 :
                    other.state='up-'+other.dir
                    other.myflag=False
                    self.exist=False
                    self.frame_count1=0
                elif other.name=='Skeleton' and c==2:
                     
                     if 'duck' not in other.state:
                
                            other.frame_count1=0
                            other.frame_count=0
                            other.state='duck-'+other.dir
                            other.background_state='duck'
                     self.exist=False
                elif other.name=='BOSS' and other.player and other.float_counter>0 and c!=2:
                    pass
                else:
                    other.health-=self.attack
                    other.health_decrement+=self.attack
                    self.exist=False
                # print(5)


class Hobbit_with_Bullet(Hobbit):
    def __init__(self,screen,x,WASD=False,speed=0,state='right',name=None,computer=None,health=100,attack=20,bullet_speed=0,player=False,bullet=True,attack_freq=3,new_factor=64,bullet_attack=100,summit=False):
        Hobbit.__init__(self,screen,x,WASD,speed,state,name,computer,health,attack,player,bullet,attack_freq,new_factor,summit)
        self.bullets=[]
        self.flag=True
        self.bullet_speed=bullet_speed
        self.bullet_attack=bullet_attack
        self.summit=summit
        
    def draw(self):
        Hobbit.draw(self)
        # print(1)
        if 'attack' in self.state:
            if self.frame_count1==6: 
                self.flag=True
            if self.frame_count1==5:

                if self.flag:
                    if not self.summit:
                        b=Bullet(self.SCREEN,"goli.png",self.char_x,self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset-24-24,speed=self.bullet_speed,dir=self.dir,attack=self.bullet_attack,player=self.player)
                    else:
                         b=Bullet(self.SCREEN,"goli6.png",self.char_x,self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset-24-24,speed=self.bullet_speed,dir=self.dir,attack=self.bullet_attack,player=self.player)
                    

                    self.bullets.append(b)
                    self.flag=False
                

        for bullet in self.bullets:
            bullet.draw()

        if not self.player:
            if 'duck' in self.state and self.computer!=None and self.computer.sr:
                text_surface = pygame.font.Font('freesansbold.ttf',50).render("GRAVITY UP !!!!", True, (0,0,0))
                text_rect = text_surface.get_rect(center=(930//2, 250))  # Center text on screen
                self.SCREEN.blit(text_surface, text_rect)
            if self.computer!=None and self.computer.cr>0:
                text_surface = pygame.font.Font('freesansbold.ttf',50).render("GRAVITY RESTORED !!!!", True, (0,0,0))
                text_rect = text_surface.get_rect(center=(930//2, 250))  # Center text on screen
                self.SCREEN.blit(text_surface, text_rect)
                self.computer.cr+=1
                if self.computer.cr==10:
                    self.computer.cr=0
                

    def frequency_manager(self, p, attack_freq, attackers):
        Hobbit.frequency_manager(self,p, attack_freq, attackers)
        if p%50==0 and not self.player:
            if 'attack' not in self.state and 'dead' not in self.state and len(attackers)>0:
                    self.frame_count1=0
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'
        if p%300==0 and not self.player and self.computer.cr!=None and self.computer.sr==False:
             if 'duck' not in self.state and 'dead' not in self.state and len(attackers)>0:
                    self.frame_count1=0
                    self.frame_count=0
                    self.state='duck-'+self.dir
                    self.background_state='duck'
                    self.computer.sr=True
            

        for i in range(len(attackers)):
            for bullet in self.bullets:
                bullet.collision(attackers[i])
                
    def collision(self,other):
        print(abs(self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)))
        c=self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)
        if (abs(self.offset-other.offset)<=40 and abs(c)<=60):
            if 'attack' in self.state and (other.exist) and ((self.dir=='right' and c<0)or (self.dir=='left' and c>0)):
                other.health-=self.attack
                other.health_decrement+=self.attack
                if not self.player:
                    self.flag=False
                if other.health<=0:
                    self.computer=None
    def state_control(self):
        keys = pygame.key.get_pressed()
        if not 'dead' in self.state:
            if not self.WASD:
                if keys[pygame.K_RIGHT]:  # Right arrow key held down
                    if self.player:
                        if (self.state!='right' and 'up' not in self.state): self.frame_count=0; self.speed_x=0;self.g=1;self.speed=0 # Right arrow key held down
                    else:
                        if (self.state!='right'): self.frame_count=0
                    self.frame_count += 1
                    self.frame_count1=0
                    self.state='right'
                    self.background_state='right'
                    self.dir='right'
                    self.char_x+=self.speed
                    
                        
                    # self.actual_x+=self.speed
                    # print(self.char_x,self.speed)
                    # print("by")
                elif keys[pygame.K_LEFT]:
                    if self.player:
                        if (self.state!='left' and 'up' not in self.state): self.frame_count=0;self.speed_x=0;self.g=1;self.speed=0
                    else:
                        if (self.state!='left'): self.frame_count=0
                    self.frame_count += 1
                    self.state='left'
                    self.frame_count1=0
                    self.char_x-=self.speed
                    self.background_state='left'
                    self.dir='left'
                    # self.actual_x-=self.speed
                    # print('bye')
                elif keys[pygame.K_DOWN]:
                    if('duck' not in self.state):self.frame_count1=0
                    self.frame_count=0
                    self.state='duck-'+self.dir
                    self.background_state='duck'
                    
                elif self.state=='right':
                    self.state='idle_right'
                    self.dir='right'
                    self.background_state='idle_right'
                elif self.state=='left':
                    self.state='idle_left'
                    self.background_state='idle_left'
                    self.dir='left'
                if keys[pygame.K_UP]:
                    self.state='up-'+self.dir
                    # print(self.char_x)
                    if self.f==0:
                        self.frame_count =0
                        self.frame_count1=0
                        # self.state='up-'
                        self.f+=1
                        # self.offset-=40
                        
                if keys[pygame.K_SPACE]:
                    if('attack' not in self.state):self.frame_count1=0
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'
            elif self.computer!=None:
                other=self.computer
                c=self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)
                
                if abs(c)>=55:
                    if 'attack' not in self.state and ((not self.player and 'duck' not in self.state) or (self.player and True)):
                        if c<0:
                            if abs(c)<=self.attack_e:
                                if (self.state!='right'): self.frame_count=0 # Right arrow key held down
                                self.frame_count += 1
                                self.frame_count1=0
                                self.state='right'
                                self.background_state='right'
                                self.dir='right'
                                self.char_x+=self.speed
                            else:
                                self.dir='right'
                                self.state='idle_right'
                        else:
                            if abs(c)<=self.attack_e:
                                if (self.state!='left'): self.frame_count=0
                                self.frame_count += 1
                                self.state='left'
                                self.frame_count1=0
                                self.char_x-=self.speed
                                self.background_state='left'
                                self.dir='left'
                            else:
                                self.dir='left'
                                self.state='idle_left'

                        
                elif 'attack' not in self.state and 'dead' not in self.state:
                    self.frame_count1=0
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'
                
                # if self.state=='right':
                #     self.state='idle_right'
                #     self.dir='right'
                #     self.background_state='idle_right'
                # elif self.state=='left':
                #     self.state='idle_left'
                #     self.background_state='idle_left'
                #     self.dir='left'

                
            else:
                if keys[pygame.K_d]:  # Right arrow key held down
                    if (self.state!='right'): self.frame_count=0 # Right arrow key held down
                    self.frame_count += 1
                    self.frame_count1=0
                    self.state='right'
                    self.background_state='right'
                    self.dir='right'
                    self.char_x+=self.speed
                    # self.actual_x+=self.SPEED
                    # print(self.char_x,self.speed)
                    # print("by")
                elif keys[pygame.K_a]:
                    if (self.state!='left'): self.frame_count=0
                    self.frame_count += 1
                    self.state='left'
                    self.frame_count1=0
                    self.char_x-=self.speed
                    self.background_state='left'
                    self.dir='left'
                    # self.actual_x-=self.SPEED
                    
                elif self.state=='right':
                    self.state='idle_right'
                    self.dir='right'
                    self.background_state='idle_right'
                elif self.state=='left':
                    self.state='idle_left'
                    self.background_state='idle_left'
                    self.dir='left'
                if keys[pygame.K_w]:
                    self.state='up-'+self.dir
                    # print(self.char_x)
                    if self.f==0:
                        self.frame_count =0
                        self.frame_count1=0
                        # self.state='up-'
                        self.f+=1
                        # self.offset-=40
                        
                elif keys[pygame.K_x]:
                    self.frame_count1=0
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'
                
                
                
            
        if(self.f!=0):
             self.offset-=self.offset_speed
             self.offset_speed-=self.gravity
             self.f+=1
             
             if(self.f==14):
                 self.f=0
                 if (not keys[pygame.K_RIGHT] and not keys[pygame.K_LEFT]):
                    self.state='idle_'+self.dir
                    self.background_state=self.state
                 self.offset_speed=30
                #  print(self.state,self.f)
                    # print("hi")
        if(self.g!=0 and ('idle' not in self.state) and self.player):
             self.speed_x+=1
             self.g+=1
             print(self.speed_x,self.SPEED,self.g)
             if(self.speed_x>=self.SPEED):
                 self.speed_x=self.SPEED
                 self.g=0

        if ('attack' in self.state) and self.frame_count1>len(self.animation_frames4):
            self.state='idle_'+self.dir
            self.background_state=self.state
            self.frame_count1=0

        if ('duck' in self.state) and self.frame_count1>6:
            self.state='idle_'+self.dir
            self.background_state=self.state
            self.frame_count1=0
            

        if ('dead' in self.state):
            self.frame_count1=min(len(self.animation_frames9)-1,self.frame_count1)
            if self.frame_count1==len(self.animation_frames9)-1:
                self.computer=None
                self.exist=False
        if self.health<=0:
            if 'dead' not in self.state:
                self.frame_count1=0
            self.state='dead-'+self.dir
            self.background_state=self.state
            # print(3)
            
            # print(self.state)
        if self.health_decrement>0:
            self.health_timer+=1
            self.healthy+=5
            if self.health_timer==20:
                self.health_decrement=0
                self.health_timer=0
                self.healthy=0
        if self.player:
            pass
            self.char_x=min(max(0,self.char_x),875)
            # self.actual_x=max(0,self.actual_x)
            # if self.actual_x==0:
            #     self.char_x=0
        # if self.player:
        #     print(self.actual_x,'hi',self.char_x)


class MartialHero(Character):
    def __init__(self,screen,x,WASD=False,speed=0,state='right',name=None,computer=None,health=100,attack=20,player=False,attack_freq=3,bullet=False):
        Character.__init__(self,screen,x,WASD,speed,state,name,computer,health,attack,player,bullet,attack_freq)
        self.spritesheet = pygame.image.load("Martial Hero/Sprites/Run.png")
        self.flipped_sprite_image = pygame.transform.flip(self.spritesheet, True, False)
        self.spritesheet1 = pygame.image.load("Martial Hero/Sprites/Idle.png")
        self.flipped_sprite_image1 = pygame.transform.flip(self.spritesheet1, True, False)
        self.spritesheet2 = pygame.image.load("Martial Hero/Sprites/Attack1.png")
        self.flipped_sprite_image2 = pygame.transform.flip(self.spritesheet2, True, False)
        self.spritesheet3 = pygame.image.load("Martial Hero/Sprites/Jump.png")
        self.flipped_sprite_image3 = pygame.transform.flip(self.spritesheet3, True, False)
        self.spritesheet4 = pygame.image.load("Martial Hero/Sprites/Death.png")
        self.flipped_sprite_image4 = pygame.transform.flip(self.spritesheet4, True, False)
        self.FRAME_WIDTH, self.FRAME_HEIGHT = 200, 200
        new_factor= 350 #96
        self.animation_frames = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(8)]
        self.animation_frames1 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(7,-1,-1)]
        self.animation_frames2 = [pygame.transform.scale(self.spritesheet1.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(8)]
        self.animation_frames3 = [pygame.transform.scale(self.flipped_sprite_image1.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(7,-1,-1)]
        self.animation_frames4 = [pygame.transform.scale(self.spritesheet2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(6)]
        self.animation_frames7 = [pygame.transform.scale(self.flipped_sprite_image2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(5,-1,-1)]
        self.animation_frames5 = [pygame.transform.scale(self.spritesheet3.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(2)]
        self.animation_frames6 = [pygame.transform.scale(self.flipped_sprite_image3.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(1,-1,-1)]
        
        self.animation_frames8 = [pygame.transform.scale(self.spritesheet4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(6)]
        self.animation_frames9 = [pygame.transform.scale(self.flipped_sprite_image4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(5,-1,-1)]
        
        # self.animation_frames10 = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
        #                     for x in range(5,-1,-1)]
        # self.animation_frames9 = [pygame.transform.scale(self.flipped_sprite_image5.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
        #                     for x in range(5,-1,-1)]
        self.offset=84 +10 + 100 #+120+20
        self.FRAME_WIDTH, self.FRAME_HEIGHT = new_factor, new_factor
        self.attack_e=800


    def health_bar(self):
         if self.health>=0:
                text_surface = pygame.font.Font('freesansbold.ttf',20).render(self.name1, True, (255,100,100))
                text_rect = text_surface.get_rect(center=(self.char_x+28+159, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-40 + 120))  # Center text on screen
                self.SCREEN.blit(text_surface, text_rect)
                if self.health_decrement>0:
                    text_surface = pygame.font.Font('freesansbold.ttf',20).render(str(self.health_decrement), True, (255,0,0))
                    text_rect = text_surface.get_rect(center=(self.char_x+28+150, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+120-self.healthy))  # Center text on screen
                    self.SCREEN.blit(text_surface, text_rect)
                pygame.draw.rect(self.SCREEN, (0,0,0), (self.char_x+14+150, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-22+120, 34, 14))
                
                pygame.draw.rect(self.SCREEN, (0,255,0), (self.char_x+16+150, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+120, (30/self.MAX_HEALTH)*self.health, 10))
                
        

class MartialHero2(Character):
    def __init__(self,screen,x,WASD=False,speed=0,state='right',name=None,computer=None,health=100,attack=20,player=False,attack_freq=3):
        Character.__init__(self,screen,x,WASD,speed,state,name,computer,health,attack,player,attack_freq)
        self.spritesheet = pygame.image.load("Martial Hero 3/Sprite/Run.png")
        print(self.spritesheet.get_width(),self.spritesheet.get_height())
        self.flipped_sprite_image = pygame.transform.flip(self.spritesheet, True, False)
        self.spritesheet1 = pygame.image.load("Martial Hero 3/Sprite/Idle.png")
        self.flipped_sprite_image1 = pygame.transform.flip(self.spritesheet1, True, False)
        self.spritesheet2 = pygame.image.load("Martial Hero 3/Sprite/Attack3.png")
        self.flipped_sprite_image2 = pygame.transform.flip(self.spritesheet2, True, False)
        self.spritesheet3 = pygame.image.load("Martial Hero 3/Sprite/Attack2.png")
        self.flipped_sprite_image3 = pygame.transform.flip(self.spritesheet3, True, False)
        self.spritesheet4 = pygame.image.load("Martial Hero 3/Sprite/Death.png")
        self.flipped_sprite_image4 = pygame.transform.flip(self.spritesheet4, True, False)
        self.FRAME_WIDTH, self.FRAME_HEIGHT = 126, 126
        new_factor= 200 #96
        self.animation_frames = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(8)]
        self.animation_frames1 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(7,-1,-1)]
        self.animation_frames2 = [pygame.transform.scale(self.spritesheet1.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(8)]
        self.animation_frames3 = [pygame.transform.scale(self.flipped_sprite_image1.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(7,-1,-1)]
        self.animation_frames4 = [pygame.transform.scale(self.spritesheet2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(9)]
        self.animation_frames7 = [pygame.transform.scale(self.flipped_sprite_image2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(8,-1,-1)]
        self.animation_frames5 = [pygame.transform.scale(self.spritesheet3.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(2)]
        self.animation_frames6 = [pygame.transform.scale(self.flipped_sprite_image3.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(1,-1,-1)]
        
        self.animation_frames8 = [pygame.transform.scale(self.spritesheet4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(6)]
        self.animation_frames9 = [pygame.transform.scale(self.flipped_sprite_image4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),(new_factor,new_factor))
                            for x in range(5,-1,-1)]
        self.offset=84 +10 + 100 #+120+20
        self.FRAME_WIDTH, self.FRAME_HEIGHT = new_factor, new_factor
        self.attack_e=800


    def health_bar(self):
         if self.health>=0:
                text_surface = pygame.font.Font('freesansbold.ttf',20).render(self.name1, True, (255,100,100))
                text_rect = text_surface.get_rect(center=(self.char_x+28+159, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-40 + 120))  # Center text on screen
                self.SCREEN.blit(text_surface, text_rect)
                if self.health_decrement>0:
                    text_surface = pygame.font.Font('freesansbold.ttf',20).render(str(self.health_decrement), True, (255,0,0))
                    text_rect = text_surface.get_rect(center=(self.char_x+28+150, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+120-self.healthy))  # Center text on screen
                    self.SCREEN.blit(text_surface, text_rect)
                pygame.draw.rect(self.SCREEN, (0,0,0), (self.char_x+14+150, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-22+120, 34, 14))
                
                pygame.draw.rect(self.SCREEN, (0,255,0), (self.char_x+16+150, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+120, (30/self.MAX_HEALTH)*self.health, 10))


class BOSS(Character):
    def __init__(self,screen,x,WASD=False,speed=0,state='right',name=None,computer=None,health=100,attack=20,bullet_speed=0,player=False,bullet=False,attack_freq=3,summit=False,bullet_attack=200):
        Character.__init__(self,screen,x,WASD,speed,state,name,computer,health,attack,player,bullet,attack_freq)
        self.spritesheet = pygame.image.load("PNGExports/Run.png")
        print(self.spritesheet.get_width(),self.spritesheet.get_height())
        self.flipped_sprite_image = pygame.transform.flip(self.spritesheet, True, False)
        self.spritesheet1 = pygame.image.load("PNGExports/Idle.png")
        self.flipped_sprite_image1 = pygame.transform.flip(self.spritesheet1, True, False)
        # self.spritesheet2 = pygame.image.load("PNGExports/ShootGun1.png")
        self.spritesheet2 = pygame.image.load("PNGExports/GroundCombo2.png")
        self.flipped_sprite_image2 = pygame.transform.flip(self.spritesheet2, True, False)
        self.spritesheet3 = pygame.image.load("PNGExports/JumpAndFall.png")
        self.flipped_sprite_image3 = pygame.transform.flip(self.spritesheet3, True, False)
        self.spritesheet4 = pygame.image.load("PNGExports/Die.png")
        self.flipped_sprite_image4 = pygame.transform.flip(self.spritesheet4, True, False)
        self.spritesheet5 = pygame.image.load("PNGExports/GroundCombo3.png")
        self.flipped_sprite_image5 = pygame.transform.flip(self.spritesheet5, True, False)
        self.spritesheet6 = pygame.image.load("PNGExports/ShootGun1.png")
        self.flipped_sprite_image6 = pygame.transform.flip(self.spritesheet6, True, False)
        self.FRAME_WIDTH, self.FRAME_HEIGHT = 80, 48
        new_factor= (250,175) #96
        self.animation_frames=[pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(8)]
        self.animation_frames1 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(7,-1,-1)]
        self.animation_frames2 = [pygame.transform.scale(self.spritesheet1.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(1)]
        self.animation_frames3 = [pygame.transform.scale(self.flipped_sprite_image1.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(0,-1,-1)]
        self.animation_frames4 = [pygame.transform.scale(self.spritesheet2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(10)] + [pygame.transform.scale(self.spritesheet5.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(14)]
        self.animation_frames7 = [pygame.transform.scale(self.flipped_sprite_image2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(9,-1,-1)] + [pygame.transform.scale(self.flipped_sprite_image5.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(13,-1,-1)]
        self.animation_frames5 = [pygame.transform.scale(self.spritesheet3.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(2)]
        self.animation_frames6 = [pygame.transform.scale(self.flipped_sprite_image3.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(1,-1,-1)]
        
        self.animation_frames8 = [pygame.transform.scale(self.spritesheet4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(4)]
        self.animation_frames9 = [pygame.transform.scale(self.flipped_sprite_image4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(3,-1,-1)]
        self.animation_frames10 = [pygame.transform.scale(self.spritesheet6.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(2)] *3
        self.animation_frames11 = [pygame.transform.scale(self.flipped_sprite_image6.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(1,-1,-1)]*3
        self.offset=84 +60 #+120+20
        self.FRAME_WIDTH, self.FRAME_HEIGHT = new_factor
        self.attack_e=800
        self.flag=True
        self.bullets=[]
        self.bullet_speed=bullet_speed
        self.bullet_attack=bullet_attack
        self.summit=summit
        self.gr=False
        self.actual_x1=1230
        self.actual_x2=930 * 2 +300
        self.sr=False
        self.cr=0
        self.sr1=14
        self.sr2=25
        self.sr3=0
        self.float=False
        self.canfloat=False
        self.float_counter=0


    def health_bar(self):
         if self.health>=0:
                text_surface = pygame.font.Font('freesansbold.ttf',20).render(self.name1, True, (255,100,100))
                text_rect = text_surface.get_rect(center=(self.char_x+28+90, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-40 + 50))  # Center text on screen
                self.SCREEN.blit(text_surface, text_rect)
                if self.health_decrement>0:
                    text_surface = pygame.font.Font('freesansbold.ttf',20).render(str(self.health_decrement), True, (255,0,0))
                    text_rect = text_surface.get_rect(center=(self.char_x+28+90, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+50-self.healthy))  # Center text on screen
                    self.SCREEN.blit(text_surface, text_rect)
                pygame.draw.rect(self.SCREEN, (0,0,0), (self.char_x+14+90, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-22+50, 34, 14))
                
                pygame.draw.rect(self.SCREEN, (0,255,0), (self.char_x+16+90, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+50, (30/self.MAX_HEALTH)*self.health, 10))

    def frequency_manager(self,p,attack_freq,attackers):
        if 'attack' in self.state:
            if p%self.attack_freq==0:
                self.frame_count1+=1
                
                if self.frame_count1==3 or self.frame_count1==13:
                    for attacker in attackers:
                        self.collision(attacker)
                    # self.collision(P4)
        elif p%3==0:
            self.frame_count1+=1
        if len(attackers)==0:
            self.computer=None
        if p%100==0 and not self.player:
            if 'duck' not in self.state and 'dead' not in self.state and len(attackers)>0:
                    self.frame_count1=0
                    self.frame_count=0
                    self.state='duck-'+self.dir
                    self.background_state='duck'
        if p%200==0  and p>=50 and self.player and self.canfloat and not self.float and self.float_counter==0:
            print(p,'hihihihihihihih')
            self.float=True
            self.float_counter=1
        

                    

        for bullet in self.bullets:
            if len(attackers)>0:
                bullet.collision(attackers[0])

    def collision(self,other):
       # print(self.offset-other.offset )
        # if self.summit and other.name=='bipolar':
        #     self.canfloat=False
        #     self.float=False
        c=self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)
        if (abs(self.offset-other.offset )<=85 and abs(c)<=80):
            if 'attack' in self.state and (other.exist) and ((self.dir=='right' and c<0)or (self.dir=='left' and c>0)):
                other.health-=self.attack
                other.health_decrement+=self.attack
                self.flag=False
                # print(other.name,other.health_decrement)
                if other.health<=0:
                    self.computer=None
            if 'attack' in other.state and (self.exist) and (((other.dir=='left' and c<0)or (other.dir=='right' and c>0))):
                self.health-=other.attack
                self.health_decrement+=other.attack
                if self.health<=0:
                    other.computer=None


    def state_control(self):
        keys = pygame.key.get_pressed()
        if not 'dead' in self.state:
            if not self.WASD:
                if keys[pygame.K_RIGHT]:  # Right arrow key held down
                    if self.player:
                        if (self.state!='right' and 'up' not in self.state): self.frame_count=0; self.speed_x=0;self.g=1;self.speed=0 # Right arrow key held down
                    else:
                        if (self.state!='right'): self.frame_count=0
                    self.frame_count += 1
                    self.frame_count1=0
                    self.state='right'
                    self.background_state='right'
                    self.dir='right'
                    self.char_x+=self.speed
                    
                    # self.actual_x+=self.speed
                    # print(self.char_x,self.speed)
                    # print("by")
                elif keys[pygame.K_LEFT]:
                    if self.player:
                        if (self.state!='left' and 'up' not in self.state): self.frame_count=0;self.speed_x=0;self.g=1;self.speed=0
                    else:
                        if (self.state!='left'): self.frame_count=0
                    self.frame_count += 1
                    self.state='left'
                    self.frame_count1=0
                    self.char_x-=self.speed
                    self.background_state='left'
                    self.dir='left'
                    # self.actual_x-=self.speed
                    # print('bye')
                elif keys[pygame.K_DOWN]:
                    if('duck' not in self.state):self.frame_count1=0
                    self.frame_count=0
                    self.state='duck-'+self.dir
                    self.background_state='duck'
                    
                elif self.state=='right':
                    self.state='idle_right'
                    self.dir='right'
                    self.background_state='idle_right'
                elif self.state=='left':
                    self.state='idle_left'
                    self.background_state='idle_left'
                    self.dir='left'
                if keys[pygame.K_UP]:
                    self.state='up-'+self.dir
                    # print(self.char_x)
                    if self.f==0:
                        self.frame_count =0
                        self.frame_count1=0
                        # self.state='up-'
                        self.f+=1
                        # self.offset-=40
                        
                elif keys[pygame.K_SPACE]:
                    if('attack' not in self.state):self.frame_count1=0
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'
            elif self.computer!=None:
                other=self.computer
                c=self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)
                
                
                if abs(c)>=75:
                    if 'duck' not in self.state:
                        if c<0:
                            if abs(c)<=self.attack_e:
                                if (self.state!='right'): self.frame_count=0 # Right arrow key held down
                                self.frame_count += 1
                                self.frame_count1=0
                                self.state='right'
                                self.background_state='right'
                                self.dir='right'
                                self.char_x+=self.speed
                            else:
                                self.dir='right'
                                self.state='idle_right'
                        else:
                            if abs(c)<=self.attack_e:
                                if (self.state!='left'): self.frame_count=0
                                self.frame_count += 1
                                self.state='left'
                                self.frame_count1=0
                                self.char_x-=self.speed
                                self.background_state='left'
                                self.dir='left'
                            else:
                                self.dir='left'
                                self.state='idle_left'

                        
                elif 'attack' not in self.state and 'dead' not in self.state:
                    self.frame_count1=0
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'
                
                # if self.state=='right':
                #     self.state='idle_right'
                #     self.dir='right'
                #     self.background_state='idle_right'
                # elif self.state=='left':
                #     self.state='idle_left'
                #     self.background_state='idle_left'
                #     self.dir='left'

                
            else:
                if keys[pygame.K_d]:  # Right arrow key held down
                    if (self.state!='right'): self.frame_count=0 # Right arrow key held down
                    self.frame_count += 1
                    self.frame_count1=0
                    self.state='right'
                    self.background_state='right'
                    self.dir='right'
                    self.char_x+=self.speed
                    # self.actual_x+=self.SPEED
                    # print(self.char_x,self.speed)
                    # print("by")
                elif keys[pygame.K_a]:
                    if (self.state!='left'): self.frame_count=0
                    self.frame_count += 1
                    self.state='left'
                    self.frame_count1=0
                    self.char_x-=self.speed
                    self.background_state='left'
                    self.dir='left'
                    # self.actual_x-=self.SPEED
                    
                elif self.state=='right':
                    self.state='idle_right'
                    self.dir='right'
                    self.background_state='idle_right'
                elif self.state=='left':
                    self.state='idle_left'
                    self.background_state='idle_left'
                    self.dir='left'
                if keys[pygame.K_w]:
                    self.state='up-'+self.dir
                    # print(self.char_x)
                    if self.f==0:
                        self.frame_count =0
                        self.frame_count1=0
                        # self.state='up-'
                        self.f+=1
                        # self.offset-=40
                        
                elif keys[pygame.K_x]:
                    self.frame_count1=0
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'
                
        
        if self.float_counter>0:
            if self.float_counter<=25:
                self.float_counter+=1
                self.offset-=1
            elif self.float_counter>=125:
                # self.float=False
                self.float_counter+=1
                self.offset+=1
                if self.float_counter==150:
                    self.float_counter=0
                    self.float=False
            else:
                self.float_counter+=1
        if ((305<=self.char_x<=420) or (self.actual_x1<=self.char_x<=self.actual_x1+120) or (self.actual_x2<=self.char_x<=self.actual_x2+120)) and self.f==0 and self.summit and not self.float:
            self.f=1
            self.offset_speed=-1
            self.state='up-'+self.dir 
            self.frame_count1=5  
        
        if self.sr and self.f==0:
            self.gravity=15
            self.sr1=6
            self.sr2=20
            self.sr3+=1
            if self.sr3==100:
                self.sr=False
                self.sr3=0
                self.sr1=14
                self.sr2=25
                self.gravity=5
                self.cr=1
            
        if(self.f!=0):
             self.offset-=self.offset_speed
             self.offset_speed-=self.gravity
             self.f+=1
             if self.f==self.sr1:
                 if ((305<=self.char_x<=420) or (self.actual_x1<=self.char_x<=self.actual_x1+120) or (self.actual_x2<=self.char_x<=self.actual_x2+120)) and self.summit and not self.float:
                     self.gr=True
             if not self.gr:       
                if(self.f==self.sr1):
                    self.f=0
                    if (not keys[pygame.K_RIGHT] and not keys[pygame.K_LEFT]):
                        self.state='idle_'+self.dir
                        self.background_state=self.state
                        
                    self.offset_speed=30
             else:
                 if(self.f==self.sr2):
                    self.f=0
                    if (not keys[pygame.K_RIGHT] and not keys[pygame.K_LEFT]):
                        self.state='idle_'+self.dir
                        self.background_state=self.state
                    self.offset_speed=30
                 self.gr=False
                 
        # if(self.f!=0):
        #      self.offset-=self.offset_speed
        #      self.offset_speed-=self.gravity
        #      self.f+=1
             
        #      if(self.f==14):
        #          self.f=0
        #          self.state='idle_'+self.dir
        #          self.background_state=self.state
        #          self.offset_speed=30
                #  print(self.state,self.f)
                    # print("hi")
        
        if(self.g!=0 and ('idle' not in self.state) and self.player):
             self.speed_x+=1
             self.g+=1
             print(self.speed_x,self.SPEED,self.g)
             if(self.speed_x>=self.SPEED):
                 self.speed_x=self.SPEED
                 self.g=0

        if ('attack' in self.state) and self.frame_count1>len(self.animation_frames4):
            self.state='idle_'+self.dir
            self.background_state=self.state
            self.frame_count1=0

        if ('duck' in self.state) and self.frame_count1>6:
            self.state='idle_'+self.dir
            self.background_state=self.state
            self.frame_count1=0
        

        if ('dead' in self.state):
            self.frame_count1=min(len(self.animation_frames9)-1,self.frame_count1)
            if self.frame_count1==len(self.animation_frames9)-1:
                self.computer=None
                self.exist=False
        if self.health<=0:
            if 'dead' not in self.state:
                self.frame_count1=0
            self.state='dead-'+self.dir
            self.background_state=self.state
            # print(3)
            
            # print(self.state)
        if self.health_decrement>0:
            self.health_timer+=1
            self.healthy+=5
            if self.health_timer==20:
                self.health_decrement=0
                self.health_timer=0
                self.healthy=0
        if self.player:
            pass
            self.char_x=min(max(-100,self.char_x),750)
            # self.actual_x=max(0,self.actual_x)
            # if self.actual_x==0:
            #     self.char_x=0
        # if self.player:
        #     print(self.actual_x,'hi',self.char_x)

    def draw(self):
        Character.draw(self)
        # print(1)
        if 'duck' in self.state:
            
            if self.frame_count1==0:
                self.flag=True
            if self.frame_count1==1:
                # print(self.state,self.frame_count1,self.flag)
                if self.flag:
                    b=Bullet(self.SCREEN,"goli2.png",self.char_x,self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset + 40,speed=self.bullet_speed,dir=self.dir,attack=self.bullet_attack,range=(45,50),player=self.player)
                    self.bullets.append(b)
                    self.flag=False
                

        for bullet in self.bullets:
            bullet.draw()
    def get_background(self,back_speed,background_x=0):
        background_speed=0
        if self.background_state=='right':
            if self.char_x>=450 and self.actual_x0>1000:
                background_speed=self.speed_x
                self.speed=0
                
            else:
                self.speed=self.speed_x
                background_speed=0
            background_x-=background_speed
            self.actual_x-=background_speed
            self.actual_x0-=background_speed
            self.actual_x1-=background_speed
            self.actual_x2-=background_speed
            #if background_x<=-930:
                #background_x=0
        elif self.background_state=='left':
            # pass
            if self.char_x<=450 and background_x<0:
                self.speed=0
                background_speed=-self.speed_x
            else:
                
                self.speed=self.speed_x
                background_speed=0
            background_x-=background_speed
            self.actual_x-=background_speed
            self.actual_x0-=background_speed
            self.actual_x1-=background_speed
            self.actual_x2-=background_speed
            background_x=min(0,background_x)
            #if background_x>=930:
                #background_x=0
        # print(background_x,'hihihii')
        return background_x,background_speed
        
class TeleBoss(Character):

    def __init__(self,screen,x,WASD=False,speed=0,state='left',name=None,computer=None,health=100,attack=20,bullet_speed=0,player=False,bullet=False,attack_freq=3):
        Character.__init__(self,screen,x,WASD,speed,state,name,computer,health,attack,player,bullet,attack_freq)
        self.spritesheet = pygame.image.load("TeleBoss.png")
        #print(self.spritesheet.get_width(),self.spritesheet.get_height())
        self.flipped_sprite_image = pygame.transform.flip(self.spritesheet, True, False)
        """self.spritesheet1 = pygame.image.load("PNGExports/Idle.png")
        self.flipped_sprite_image1 = pygame.transform.flip(self.spritesheet1, True, False)
        # self.spritesheet2 = pygame.image.load("PNGExports/ShootGun1.png")
        self.spritesheet2 = pygame.image.load("PNGExports/GroundCombo2.png")
        self.flipped_sprite_image2 = pygame.transform.flip(self.spritesheet2, True, False)
        self.spritesheet3 = pygame.image.load("PNGExports/JumpAndFall.png")
        self.flipped_sprite_image3 = pygame.transform.flip(self.spritesheet3, True, False)
        self.spritesheet4 = pygame.image.load("PNGExports/Die.png")
        self.flipped_sprite_image4 = pygame.transform.flip(self.spritesheet4, True, False)
        self.spritesheet5 = pygame.image.load("PNGExports/GroundCombo3.png")
        self.flipped_sprite_image5 = pygame.transform.flip(self.spritesheet5, True, False)
        self.spritesheet6 = pygame.image.load("PNGExports/ShootGun1.png")
        self.flipped_sprite_image6 = pygame.transform.flip(self.spritesheet6, True, False)"""
        self.FRAME_WIDTH, self.FRAME_HEIGHT = 64, 64

        new_factor= (200,200) #96
        self.animation_frames=[pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 256, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(8)]
        self.animation_frames1 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((9*64+ x * self.FRAME_WIDTH, 256, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(7,-1,-1)]
        self.animation_frames2 = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(1)]
        self.animation_frames3 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((16*64 +x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(0,-1,-1)]
        
        self.animation_frames4 = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 11*64, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(9)]  #[pygame.transform.scale(self.spritesheet5.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(14)]
        self.animation_frames7 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((8*64+ x * self.FRAME_WIDTH, 11*64, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(8,-1,-1)] # [pygame.transform.scale(self.flipped_sprite_image5.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(13,-1,-1)]
        self.animation_frames4=self.animation_frames4[:3]+[self.animation_frames4[4]]*5+self.animation_frames4[5:]
        self.animation_frames7=self.animation_frames7[:3]+[self.animation_frames7[4]]*5+self.animation_frames7[5:]

        self.animation_frames5 = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 14*64, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(8)]
        self.animation_frames6 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((9*64+ x * self.FRAME_WIDTH, 14*64, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(7,-1,-1)]
        
        self.animation_frames8 = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 15*64, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(17)]
        self.animation_frames9 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 15*64, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(16,-1,-1)]
        self.animation_frames10 = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 9*64, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(10)] + [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 10*64, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(6)] + [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 12*64, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(9)] 
        self.animation_frames11 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((7*64+ x * self.FRAME_WIDTH, 9*64, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(9,-1,-1)] + [pygame.transform.scale(self.flipped_sprite_image.subsurface(( 11*64 + x * self.FRAME_WIDTH, 10*64, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(5,-1,-1)] + [pygame.transform.scale(self.flipped_sprite_image.subsurface((8*64 +x * self.FRAME_WIDTH, 12*64, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(8,-1,-1)] 
        self.offset=84 +60+40 #+120+20
        self.FRAME_WIDTH, self.FRAME_HEIGHT = new_factor
        self.attack_e=1000
        self.flag=True
        self.bullets=[]
        self.bullet_speed=bullet_speed
        self.attack_flag=True
        self.attack_counter=0
        self.attack_speed=0
        self.myflag=False
        self.myvar=False
        self.p=0
        self.complete=True


    def state_control(self):
        keys = pygame.key.get_pressed()
        if not 'dead' in self.state:
            if not self.WASD:
                if keys[pygame.K_RIGHT]:  # Right arrow key held down
                    if self.player:
                        if (self.state!='right' and 'up' not in self.state): self.frame_count=0; self.speed_x=0;self.g=1;self.speed=0 # Right arrow key held down
                    else:
                        if (self.state!='right'): self.frame_count=0
                    self.frame_count += 1
                    self.frame_count1=0
                    self.state='right'
                    self.background_state='right'
                    self.dir='right'
                    self.char_x+=self.speed
                    
                        
                    # self.actual_x+=self.speed
                    # print(self.char_x,self.speed)
                    # print("by")
                elif keys[pygame.K_LEFT]:
                    if self.player:
                        if (self.state!='left' and 'up' not in self.state): self.frame_count=0;self.speed_x=0;self.g=1;self.speed=0
                    else:
                        if (self.state!='left'): self.frame_count=0
                    self.frame_count += 1
                    self.state='left'
                    self.frame_count1=0
                    self.char_x-=self.speed
                    self.background_state='left'
                    self.dir='left'
                    # self.actual_x-=self.speed
                    # print('bye')
                elif keys[pygame.K_DOWN]:
                    if('duck' not in self.state):self.frame_count1=0
                    self.frame_count=0
                    self.state='duck-'+self.dir
                    self.background_state='duck'
                    
                elif self.state=='right':
                    self.state='idle_right'
                    self.dir='right'
                    self.background_state='idle_right'
                elif self.state=='left':
                    self.state='idle_left'
                    self.background_state='idle_left'
                    self.dir='left'
                if keys[pygame.K_UP]:
                    self.state='up-'+self.dir
                    # print(self.char_x)
                    if self.f==0:
                        self.frame_count =0
                        self.frame_count1=0
                        # self.state='up-'
                        self.f+=1
                        # self.offset-=40
                        
                if keys[pygame.K_SPACE]:
                    if('attack' not in self.state):self.frame_count1=0
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'
            elif self.computer!=None:
                other=self.computer
                c=self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)
                if abs(c)<=600:
                    if self.attack_flag and self.complete:
                        f=random.randint(0,8)

                       

                        

                        if 'up' not in self.state and 'dead' not in self.state and f in [0,3]:
                            self.frame_count1=0
                            self.frame_count=0
                            self.complete=False
                            self.myvar=False
                            # self.attack_speed=0
                            # self.myflag=False
                            if c<0:
                                self.dir='right'
                            else:
                                self.dir='left'
                            self.state='up-'+self.dir
                            self.background_state='up'

                        elif 'duck' not in self.state and 'dead' not in self.state and f in [1,4]:
                            self.frame_count1=0
                            self.frame_count=0
                            self.complete=False
                            # self.attack_speed=0
                            # self.myflag=False
                            if c<0:
                                self.dir='right'
                            else:
                                self.dir='left'
                            self.state='duck-'+self.dir
                            self.background_state='duck'
                        
                        elif True or 'attack' not in self.state and 'dead' not in self.state:
                            self.frame_count1=0
                            self.frame_count=0
                            self.attack_speed=0
                            self.myflag=False
                            self.complete=False
                            if c<0:
                                self.dir='right'
                            else:
                                self.dir='left'
                            self.state='attack-'+self.dir
                            self.background_state='attack'

                        
                elif self.complete:
                    self.frame_count1=0
                    self.frame_count=0
                    self.state='idle_'+self.dir
                    self.background_state='attack'
                # if abs(c)<=self.attack_e:
                #     if self.attack_flag:
                #         if 'attack' not in self.state and 'dead' not in self.state:
                #             self.frame_count1=0
                #             self.frame_count=0
                #             self.state='attack-'+self.dir
                #             self.background_state='attack'
                #     else:
                #             self.frame_count1=0
                #             self.frame_count=0
                #             self.state='idle_'+self.dir
                #             self.background_state='idle' 
                # else:
                #     self.frame_count1=0
                #     self.frame_count=0
                #     self.state='idle_'+self.dir
                #     self.background_state='idle' 


                
                # if self.state=='right':
                #     self.state='idle_right'
                #     self.dir='right'
                #     self.background_state='idle_right'
                # elif self.state=='left':
                #     self.state='idle_left'
                #     self.background_state='idle_left'
                #     self.dir='left'

                
            else:
                if keys[pygame.K_d]:  # Right arrow key held down
                    if (self.state!='right'): self.frame_count=0 # Right arrow key held down
                    self.frame_count += 1
                    self.frame_count1=0
                    self.state='right'
                    self.background_state='right'
                    self.dir='right'
                    self.char_x+=self.speed
                    # self.actual_x+=self.SPEED
                    # print(self.char_x,self.speed)
                    # print("by")
                elif keys[pygame.K_a]:
                    if (self.state!='left'): self.frame_count=0
                    self.frame_count += 1
                    self.state='left'
                    self.frame_count1=0
                    self.char_x-=self.speed
                    self.background_state='left'
                    self.dir='left'
                    # self.actual_x-=self.SPEED
                    
                elif self.state=='right':
                    self.state='idle_right'
                    self.dir='right'
                    self.background_state='idle_right'
                elif self.state=='left':
                    self.state='idle_left'
                    self.background_state='idle_left'
                    self.dir='left'
                if keys[pygame.K_w]:
                    self.state='up-'+self.dir
                    # print(self.char_x)
                    if self.f==0:
                        self.frame_count =0
                        self.frame_count1=0
                        # self.state='up-'
                        self.f+=1
                        # self.offset-=40
                        
                elif keys[pygame.K_x]:
                    self.frame_count1=0
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'
                
                
                
        # print(self.state,self.animation_frames2) 
        # if(self.f!=0):
        #      self.offset-=self.offset_speed
        #      self.offset_speed-=self.gravity
        #      self.f+=1
             
        #      if(self.f==14):
        #          self.f=0
        #          if (not keys[pygame.K_RIGHT] and not keys[pygame.K_LEFT]):
        #             self.state='idle_'+self.dir
        #             self.background_state=self.state
        #          self.offset_speed=30
                #  print(self.state,self.f)
                    # print("hi")
        if(self.g!=0 and ('idle' not in self.state) and self.player):
             self.speed_x+=1
             self.g+=1
            #  print(self.speed_x,self.SPEED,self.g)
             if(self.speed_x>=self.SPEED):
                 self.speed_x=self.SPEED
                 self.g=0

        if ('attack' in self.state):
            c=self.char_x+(self.FRAME_WIDTH//2) -self.computer.char_x-(self.computer.FRAME_WIDTH//2)
            f=random.randint(0,100)
            # print(abs(c))
            if ((c<0 and self.dir=='left') or (c>0 and self.dir=='right')) and self.myflag==False and 'up' not in other.state:
                other.health-=self.attack
                # print(1)
                other.health_decrement+=self.attack
                
                # if other.health<=0:
                #     self.computer=None
                self.myflag=True
            if self.frame_count1>len(self.animation_frames4) or (f==1 and ((c<0 and self.dir=='left') or (c>0 and self.dir=='right')) and abs(c)>=80):
                self.state='idle_'+self.dir
                self.background_state=self.state
                self.frame_count1=0
                self.attack_flag=False
                self.attack_speed=0
                self.myflag=False
                self.complete=True
            else:
                if self.dir=='right':
                    self.char_x+=self.attack_speed
                else:
                    self.char_x-=self.attack_speed
                self.char_x=max(-100,min(self.char_x,800))
                self.attack_speed+=2
                if self.attack_speed==20:
                    self.attack_speed=100

        

                
        

                

        if ('duck' in self.state):
            # print(self.frame_count1)
            if self.frame_count1>25:
                self.state='idle_'+self.dir
                self.background_state=self.state
                self.frame_count1=0
                self.attack_flag=False
                self.p=0
                self.myvar=0
                self.complete=True
            else:
                f=random.randint(0,5)
                if f==1:
                    b=Bullet(self.SCREEN,"goli5.png",random.randint(0,1000),0,speed=self.bullet_speed,dir='left',attack=200,angle=True,range=(40,60))
                    self.bullets.append(b)
                    # b=Bullet(self.SCREEN,"goli5.png",random.randint(0,1600),0,speed=self.bullet_speed,dir='left',attack=200,angle=True,range=(40,60))
                    # self.bullets.append(b)

        if ('up' in self.state):
            if self.frame_count1>8:
                self.state='idle_'+self.dir
                self.background_state=self.state
                self.frame_count1=0
                self.attack_flag=False
                self.complete=True
                self.myvar=False
            else:
                if self.frame_count1==3:
                    self.char_c=1500
                elif self.frame_count1==7:
                    if not self.myvar:
                        # print(self.char_x,self.computer.char_x)
                        self.frame_count1=3
                        self.char_x=random.randint(0,730)
                        self.myvar=True
               
                    


        if self.attack_flag==False:
            self.attack_counter+=1
            if self.attack_counter==20:
                self.attack_flag=True
                self.attack_counter=0

        if ('dead' in self.state):
            self.frame_count1=min(len(self.animation_frames9)-1,self.frame_count1)
            if self.frame_count1==len(self.animation_frames9)-1:
                self.computer=None
                self.exist=False
        if self.health<=0:
            if 'dead' not in self.state:
                self.frame_count1=0
            self.state='dead-'+self.dir
            self.background_state=self.state
            # print(3)
            
            # print(self.state)
        if self.health_decrement>0:
            self.health_timer+=1
            self.healthy+=5
            if self.health_timer==20:
                self.health_decrement=0
                self.health_timer=0
                self.healthy=0
        if self.player:
            pass
            self.char_x=min(max(0,self.char_x),800)
            # self.actual_x=max(0,self.actual_x)
            # if self.actual_x==0:
            #     self.char_x=0
        # if self.player:
        #     print(self.actual_x,'hi',self.char_x)


    # def collision(self,other):
    #     # print(abs(self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)))
    #     print(abs(self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)),'hi',abs(self.offset-other.offset ),self.char_x,other.char_x)
    #     c=self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)
    #     if (abs(self.offset-other.offset )<=20 and abs(c)<=60):
    #         if 'attack' in self.state and (other.exist) and ((self.dir=='right' and c<0)or (self.dir=='left' and c>0)):
    #             other.health-=self.attack
    #             # print(1)
    #             other.health_decrement+=self.attack
    #             # print(other.name,other.health_decrement)
    #             if other.health<=0:
    #                 self.computer=None

    def health_bar(self):
         if self.health>=0:
                text_surface = pygame.font.Font('freesansbold.ttf',20).render(self.name1, True, (255,100,100))
                text_rect = text_surface.get_rect(center=(self.char_x+28+65, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-40 + 50))  # Center text on screen
                self.SCREEN.blit(text_surface, text_rect)
                if self.health_decrement>0:
                    text_surface = pygame.font.Font('freesansbold.ttf',20).render(str(self.health_decrement), True, (255,0,0))
                    text_rect = text_surface.get_rect(center=(self.char_x+28+65, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+50-self.healthy))  # Center text on screen
                    self.SCREEN.blit(text_surface, text_rect)
                pygame.draw.rect(self.SCREEN, (0,0,0), (self.char_x+14+65, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-22+50, 34, 14))
                
                pygame.draw.rect(self.SCREEN, (0,255,0), (self.char_x+16+65, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+50, (30/self.MAX_HEALTH)*self.health, 10))
    def frequency_manager(self, p, attack_freq, attackers):
        Character.frequency_manager(self,p, attack_freq, attackers)
        for bullet in self.bullets:
            bullet.collision(attackers[0])

    def draw(self):
        Character.draw(self)
        for bullet in self.bullets:
            bullet.draw()
    def collision(self,other):
        # print(abs(self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)))
        c=self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)
        if (abs(self.offset-other.offset)<=60 and abs(c)<=60):
            if 'attack' in self.state and (other.exist) and ((self.dir=='right' and c<0)or (self.dir=='left' and c>0)) and 'up' not in other.state:
                print(other.state)
                other.health-=self.attack
                other.health_decrement+=self.attack
                # print(other.name,other.health_decrement)
                if other.health<=0:
                    self.computer=None


class Final_Char(Character):
    def __init__(self,screen,x,WASD=False,speed=0,state='right',name=None,computer=None,health=100,attack=20,bullet_speed=0,player=False,bullet=False,attack_freq=3,summit=False):
        Character.__init__(self,screen,x,WASD,speed,state,name,computer,health,attack,player,bullet,attack_freq)
        self.spritesheet = pygame.image.load("Final_Char.png")
        print(self.spritesheet.get_width(),self.spritesheet.get_height())
        self.flipped_sprite_image = pygame.transform.flip(self.spritesheet, True, False)
        # self.spritesheet1 = pygame.image.load("PNGExports/Idle.png")
        # self.flipped_sprite_image1 = pygame.transform.flip(self.spritesheet1, True, False)
        # # self.spritesheet2 = pygame.image.load("PNGExports/ShootGun1.png")
        # self.spritesheet2 = pygame.image.load("PNGExports/GroundCombo2.png")
        # self.flipped_sprite_image2 = pygame.transform.flip(self.spritesheet2, True, False)
        # self.spritesheet3 = pygame.image.load("PNGExports/JumpAndFall.png")
        # self.flipped_sprite_image3 = pygame.transform.flip(self.spritesheet3, True, False)
        # self.spritesheet4 = pygame.image.load("PNGExports/Die.png")
        # self.flipped_sprite_image4 = pygame.transform.flip(self.spritesheet4, True, False)
        # self.spritesheet5 = pygame.image.load("PNGExports/GroundCombo3.png")
        # self.flipped_sprite_image5 = pygame.transform.flip(self.spritesheet5, True, False)
        # self.spritesheet6 = pygame.image.load("PNGExports/ShootGun1.png")
        # self.flipped_sprite_image6 = pygame.transform.flip(self.spritesheet6, True, False)
        self.FRAME_WIDTH, self.FRAME_HEIGHT = 130, 97
        new_factor= (350,300) #96
        self.animation_frames=[pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(10)]
        self.animation_frames1 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(9,-1,-1)]
        self.animation_frames2 = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 22*97, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(1)]
        self.animation_frames3 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((9*130+x * self.FRAME_WIDTH, 22*97, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(0,-1,-1)]
        # self.animation_frames4 = [pygame.transform.scale(self.spritesheet2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(10)] + [pygame.transform.scale(self.spritesheet5.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(14)]
        # self.animation_frames7 = [pygame.transform.scale(self.flipped_sprite_image2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(9,-1,-1)] + [pygame.transform.scale(self.flipped_sprite_image5.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(13,-1,-1)]
        self.animation_frames5 = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 6*97, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(10)]
        self.animation_frames6 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 6*97, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(9,-1,-1)]
        
        # self.animation_frames8 = [pygame.transform.scale(self.spritesheet4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(4)]
        # self.animation_frames9 = [pygame.transform.scale(self.flipped_sprite_image4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(3,-1,-1)]
        # self.animation_frames10 = [pygame.transform.scale(self.spritesheet6.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(2)] *3
        # self.animation_frames11 = [pygame.transform.scale(self.flipped_sprite_image6.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(1,-1,-1)]*3
        self.offset=84 +60+ 100 #+120+20
        self.FRAME_WIDTH, self.FRAME_HEIGHT = new_factor
        self.attack_e=800
        self.flag=True
        self.bullets=[]
        self.bullet_speed=bullet_speed
        self.summit=summit
        self.gr=False
        self.actual_x1=1230
        self.actual_x2=930 * 2 +300
        self.sr=False
        self.cr=0
        self.sr1=14
        self.sr2=25
        self.sr3=0


    def health_bar(self):
         if self.health>=0:
                text_surface = pygame.font.Font('freesansbold.ttf',20).render(self.name1, True, (255,100,100))
                text_rect = text_surface.get_rect(center=(self.char_x+28+90, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-40 + 50))  # Center text on screen
                self.SCREEN.blit(text_surface, text_rect)
                if self.health_decrement>0:
                    text_surface = pygame.font.Font('freesansbold.ttf',20).render(str(self.health_decrement), True, (255,0,0))
                    text_rect = text_surface.get_rect(center=(self.char_x+28+90, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+50-self.healthy))  # Center text on screen
                    self.SCREEN.blit(text_surface, text_rect)
                pygame.draw.rect(self.SCREEN, (0,0,0), (self.char_x+14+90, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-22+50, 34, 14))
                
                pygame.draw.rect(self.SCREEN, (0,255,0), (self.char_x+16+90, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+50, (30/self.MAX_HEALTH)*self.health, 10))




class Mushroom(Character):
    def __init__(self,screen,x,WASD=False,speed=0,state='right',name=None,computer=None,health=100,attack=20,bullet_speed=0,player=False,bullet=False,attack_freq=3,summit=False):
        Character.__init__(self,screen,x,WASD,speed,state,name,computer,health,attack,player,bullet,attack_freq)
        self.spritesheet = pygame.image.load("Monsters_Creatures_Fantasy/Mushroom/Run.png")
        print(self.spritesheet.get_width(),self.spritesheet.get_height())
        self.flipped_sprite_image = pygame.transform.flip(self.spritesheet, True, False)
        self.spritesheet1 = pygame.image.load("Monsters_Creatures_Fantasy/Mushroom/Idle.png")
        self.flipped_sprite_image1 = pygame.transform.flip(self.spritesheet1, True, False)
        # self.spritesheet2 = pygame.image.load("PNGExports/ShootGun1.png")
        self.spritesheet2 = pygame.image.load("Monsters_Creatures_Fantasy/Mushroom/Attack.png")
        self.flipped_sprite_image2 = pygame.transform.flip(self.spritesheet2, True, False)
        self.spritesheet3 = pygame.image.load("PNGExports/JumpAndFall.png")
        self.flipped_sprite_image3 = pygame.transform.flip(self.spritesheet3, True, False)
        self.spritesheet4 = pygame.image.load("Monsters_Creatures_Fantasy/Mushroom/Death.png")
        self.flipped_sprite_image4 = pygame.transform.flip(self.spritesheet4, True, False)
        self.spritesheet5 = pygame.image.load("PNGExports/GroundCombo3.png")
        self.flipped_sprite_image5 = pygame.transform.flip(self.spritesheet5, True, False)
        self.spritesheet6 = pygame.image.load("PNGExports/GroundCombo3.png")
        self.flipped_sprite_image6 = pygame.transform.flip(self.spritesheet6, True, False)
        self.FRAME_WIDTH, self.FRAME_HEIGHT = 150, 150
        new_factor= (300,300) #96
        self.animation_frames=[pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(8)]
        self.animation_frames1 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(7,-1,-1)]
        self.animation_frames2 = [pygame.transform.scale(self.spritesheet1.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(4)]
        self.animation_frames3 = [pygame.transform.scale(self.flipped_sprite_image1.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(3,-1,-1)]
        self.animation_frames4 = [pygame.transform.scale(self.spritesheet2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(8)] #+ [pygame.transform.scale(self.spritesheet5.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(14)]
        self.animation_frames7 = [pygame.transform.scale(self.flipped_sprite_image2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(7,-1,-1)] #+ [pygame.transform.scale(self.flipped_sprite_image5.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(13,-1,-1)]
        # self.animation_frames5 = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 6*97, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(10)]
        # self.animation_frames6 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 6*97, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(9,-1,-1)]
        
        self.animation_frames8 = [pygame.transform.scale(self.spritesheet4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(4)]
        self.animation_frames9 = [pygame.transform.scale(self.flipped_sprite_image4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(3,-1,-1)]
        # self.animation_frames10 = [pygame.transform.scale(self.spritesheet6.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(4)]
        # self.animation_frames11 = [pygame.transform.scale(self.flipped_sprite_image6.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(3,-1,-1)]
        self.offset=84 +60+40 #+120+20
        self.FRAME_WIDTH, self.FRAME_HEIGHT = new_factor
        self.attack_e=600
        self.flag=True
        self.bullets=[]
        self.bullet_speed=bullet_speed
        self.summit=summit
        self.gr=False
        self.actual_x1=1230
        self.actual_x2=930 * 2 +300
        self.sr=False
        self.cr=0
        self.sr1=14
        self.sr2=25
        self.sr3=0


    def health_bar(self):
         if self.health>=0:
                text_surface = pygame.font.Font('freesansbold.ttf',20).render(self.name1, True, (255,100,100))
                text_rect = text_surface.get_rect(center=(self.char_x+28+120, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-40 + 110))  # Center text on screen
                self.SCREEN.blit(text_surface, text_rect)
                if self.health_decrement>0:
                    text_surface = pygame.font.Font('freesansbold.ttf',20).render(str(self.health_decrement), True, (255,0,0))
                    text_rect = text_surface.get_rect(center=(self.char_x+28+120, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+ 110-self.healthy))  # Center text on screen
                    self.SCREEN.blit(text_surface, text_rect)
                pygame.draw.rect(self.SCREEN, (0,0,0), (self.char_x+14+120, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-22+ 110, 34, 14))
                
                pygame.draw.rect(self.SCREEN, (0,255,0), (self.char_x+16+120, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+ 110, (30/self.MAX_HEALTH)*self.health, 10))


    def frequency_manager(self,p,attack_freq,attackers):
        if 'attack' in self.state:
            if p%self.attack_freq==0:
                self.frame_count1+=1
                
                if self.frame_count1==7:
                    for attacker in attackers:
                        self.collision(attacker)
                    # self.collision(P4)
        elif p%3==0:
            self.frame_count1+=1
        if len(attackers)==0:
            self.computer=None


class Skeleton(Character):
    def __init__(self,screen,x,WASD=False,speed=0,state='right',name=None,computer=None,health=100,attack=20,bullet_speed=0,player=False,bullet=False,attack_freq=3,summit=False):
        Character.__init__(self,screen,x,WASD,speed,state,name,computer,health,attack,player,bullet,attack_freq)
        self.spritesheet = pygame.image.load("Monsters_Creatures_Fantasy/Skeleton/Walk.png")
        print(self.spritesheet.get_width(),self.spritesheet.get_height())
        self.flipped_sprite_image = pygame.transform.flip(self.spritesheet, True, False)
        self.spritesheet1 = pygame.image.load("Monsters_Creatures_Fantasy/Skeleton/Idle.png")
        self.flipped_sprite_image1 = pygame.transform.flip(self.spritesheet1, True, False)
        # self.spritesheet2 = pygame.image.load("PNGExports/ShootGun1.png")
        self.spritesheet2 = pygame.image.load("Monsters_Creatures_Fantasy/Skeleton/Attack.png")
        self.flipped_sprite_image2 = pygame.transform.flip(self.spritesheet2, True, False)
        self.spritesheet3 = pygame.image.load("PNGExports/JumpAndFall.png")
        self.flipped_sprite_image3 = pygame.transform.flip(self.spritesheet3, True, False)
        self.spritesheet4 = pygame.image.load("Monsters_Creatures_Fantasy/Skeleton/Death.png")
        self.flipped_sprite_image4 = pygame.transform.flip(self.spritesheet4, True, False)
        self.spritesheet5 = pygame.image.load("PNGExports/GroundCombo3.png")
        self.flipped_sprite_image5 = pygame.transform.flip(self.spritesheet5, True, False)
        self.spritesheet6 = pygame.image.load("Monsters_Creatures_Fantasy/Skeleton/Shield.png")
        self.flipped_sprite_image6 = pygame.transform.flip(self.spritesheet6, True, False)
        self.FRAME_WIDTH, self.FRAME_HEIGHT = 150, 150
        new_factor= (300,300) #96
        self.animation_frames=[pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(4)]
        self.animation_frames1 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(3,-1,-1)]
        self.animation_frames2 = [pygame.transform.scale(self.spritesheet1.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(4)]
        self.animation_frames3 = [pygame.transform.scale(self.flipped_sprite_image1.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(3,-1,-1)]
        self.animation_frames4 = [pygame.transform.scale(self.spritesheet2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(8)] #+ [pygame.transform.scale(self.spritesheet5.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(14)]
        self.animation_frames7 = [pygame.transform.scale(self.flipped_sprite_image2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(7,-1,-1)] #+ [pygame.transform.scale(self.flipped_sprite_image5.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(13,-1,-1)]
        # self.animation_frames5 = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 6*97, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(10)]
        # self.animation_frames6 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 6*97, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(9,-1,-1)]
        
        self.animation_frames8 = [pygame.transform.scale(self.spritesheet4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(4)]
        self.animation_frames9 = [pygame.transform.scale(self.flipped_sprite_image4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(3,-1,-1)]
        self.animation_frames10 = [pygame.transform.scale(self.spritesheet6.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(4)] 
        self.animation_frames11 = [pygame.transform.scale(self.flipped_sprite_image6.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(3,-1,-1)]
        self.offset=84 +60+40 #+120+20
        self.FRAME_WIDTH, self.FRAME_HEIGHT = new_factor
        self.attack_e=600
        self.flag=True
        self.bullets=[]
        self.bullet_speed=bullet_speed
        self.summit=summit
        self.gr=False
        self.actual_x1=1230
        self.actual_x2=930 * 2 +300
        self.sr=False
        self.cr=0
        self.sr1=14
        self.sr2=25
        self.sr3=0
        self.shield=False
        self.canshield=False


    def health_bar(self):
         if self.health>=0:
                text_surface = pygame.font.Font('freesansbold.ttf',20).render(self.name1, True, (255,100,100))
                text_rect = text_surface.get_rect(center=(self.char_x+28+120, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-40 + 110))  # Center text on screen
                self.SCREEN.blit(text_surface, text_rect)
                if self.health_decrement>0:
                    text_surface = pygame.font.Font('freesansbold.ttf',20).render(str(self.health_decrement), True, (255,0,0))
                    text_rect = text_surface.get_rect(center=(self.char_x+28+120, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+ 110-self.healthy))  # Center text on screen
                    self.SCREEN.blit(text_surface, text_rect)
                pygame.draw.rect(self.SCREEN, (0,0,0), (self.char_x+14+120, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-22+ 110, 34, 14))
                
                pygame.draw.rect(self.SCREEN, (0,255,0), (self.char_x+16+120, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+ 110, (30/self.MAX_HEALTH)*self.health, 10))


    def frequency_manager(self,p,attack_freq,attackers):
        if 'attack' in self.state:
            if p%self.attack_freq==0:
                self.frame_count1+=1
                
                if self.frame_count1==7:
                    for attacker in attackers:
                        self.collision(attacker)
                    # self.collision(P4)
        elif p%3==0:
            self.frame_count1+=1
        if len(attackers)==0:
            self.computer=None

        # if self.shield and p%200==0 and p>0:
        #     if 'duck' not in self.state:
                
        #         self.frame_count1=0
        #         self.frame_count=0
        #         self.state='duck-'+self.dir
        #         self.background_state='duck'

    def state_control(self):
        keys = pygame.key.get_pressed()
        if not 'dead' in self.state:
            if not self.WASD:
                if keys[pygame.K_RIGHT]:  # Right arrow key held down
                    if self.player:
                        if (self.state!='right' and 'up' not in self.state): self.frame_count=0; self.speed_x=0;self.g=1;self.speed=0 # Right arrow key held down
                    else:
                        if (self.state!='right'): self.frame_count=0
                    self.frame_count += 1
                    self.frame_count1=0
                    self.state='right'
                    self.background_state='right'
                    self.dir='right'
                    self.char_x+=self.speed
                    
                        
                    # self.actual_x+=self.speed
                    # print(self.char_x,self.speed)
                    # print("by")
                elif keys[pygame.K_LEFT]:
                    if self.player:
                        if (self.state!='left' and 'up' not in self.state): self.frame_count=0;self.speed_x=0;self.g=1;self.speed=0
                    else:
                        if (self.state!='left'): self.frame_count=0
                    self.frame_count += 1
                    self.state='left'
                    self.frame_count1=0
                    self.char_x-=self.speed
                    self.background_state='left'
                    self.dir='left'
                    # self.actual_x-=self.speed
                    # print('bye')
                elif keys[pygame.K_DOWN]:
                    if('duck' not in self.state):self.frame_count1=0
                    self.frame_count=0
                    self.state='duck-'+self.dir
                    self.background_state='duck'
                    
                elif self.state=='right':
                    self.state='idle_right'
                    self.dir='right'
                    self.background_state='idle_right'
                elif self.state=='left':
                    self.state='idle_left'
                    self.background_state='idle_left'
                    self.dir='left'
                if keys[pygame.K_UP]:
                    self.state='up-'+self.dir
                    # print(self.char_x)
                    if self.f==0:
                        self.frame_count =0
                        self.frame_count1=0
                        # self.state='up-'
                        self.f+=1
                        # self.offset-=40
                        
                if keys[pygame.K_SPACE]:
                    if('attack' not in self.state):self.frame_count1=0
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'
            elif self.computer!=None:
                other=self.computer
                c=self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)
                
                if abs(c)>=55:
                    if 'duck' not in self.state:
                        if c<0:
                            if abs(c)<=self.attack_e:
                                if (self.state!='right'): self.frame_count=0 # Right arrow key held down
                                self.frame_count += 1
                                self.frame_count1=0
                                self.state='right'
                                self.background_state='right'
                                self.dir='right'
                                self.char_x+=self.speed
                            else:
                                self.dir='right'
                                self.state='idle_right'
                        else:
                            if abs(c)<=self.attack_e:
                                if (self.state!='left'): self.frame_count=0
                                self.frame_count += 1
                                self.state='left'
                                self.frame_count1=0
                                self.char_x-=self.speed
                                self.background_state='left'
                                self.dir='left'
                            else:
                                self.dir='left'
                                self.state='idle_left'

                        
                elif 'attack' not in self.state and 'dead' not in self.state:
                    self.frame_count1=0
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'
                
                # if self.state=='right':
                #     self.state='idle_right'
                #     self.dir='right'
                #     self.background_state='idle_right'
                # elif self.state=='left':
                #     self.state='idle_left'
                #     self.background_state='idle_left'
                #     self.dir='left'

                
            else:
                if keys[pygame.K_d]:  # Right arrow key held down
                    if (self.state!='right'): self.frame_count=0 # Right arrow key held down
                    self.frame_count += 1
                    self.frame_count1=0
                    self.state='right'
                    self.background_state='right'
                    self.dir='right'
                    self.char_x+=self.speed
                    # self.actual_x+=self.SPEED
                    # print(self.char_x,self.speed)
                    # print("by")
                elif keys[pygame.K_a]:
                    if (self.state!='left'): self.frame_count=0
                    self.frame_count += 1
                    self.state='left'
                    self.frame_count1=0
                    self.char_x-=self.speed
                    self.background_state='left'
                    self.dir='left'
                    # self.actual_x-=self.SPEED
                    
                elif self.state=='right':
                    self.state='idle_right'
                    self.dir='right'
                    self.background_state='idle_right'
                elif self.state=='left':
                    self.state='idle_left'
                    self.background_state='idle_left'
                    self.dir='left'
                if keys[pygame.K_w]:
                    self.state='up-'+self.dir
                    # print(self.char_x)
                    if self.f==0:
                        self.frame_count =0
                        self.frame_count1=0
                        # self.state='up-'
                        self.f+=1
                        # self.offset-=40
                        
                elif keys[pygame.K_x]:
                    self.frame_count1=0
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'
                
                
                
            
        if(self.f!=0):
             self.offset-=self.offset_speed
             self.offset_speed-=self.gravity
             self.f+=1
             
             if(self.f==14):
                 self.f=0
                 if (not keys[pygame.K_RIGHT] and not keys[pygame.K_LEFT]):
                    self.state='idle_'+self.dir
                    self.background_state=self.state
                 self.offset_speed=30
                #  print(self.state,self.f)
                    # print("hi")
        if(self.g!=0 and ('idle' not in self.state) and self.player):
             self.speed_x+=1
             self.g+=1
             print(self.speed_x,self.SPEED,self.g)
             if(self.speed_x>=self.SPEED):
                 self.speed_x=self.SPEED
                 self.g=0

        if ('attack' in self.state) and self.frame_count1>len(self.animation_frames4):
            self.state='idle_'+self.dir
            self.background_state=self.state
            self.frame_count1=0

        if ('duck' in self.state) and self.frame_count1>len(self.animation_frames10):
            self.state='idle_'+self.dir
            self.background_state=self.state
            self.frame_count1=0
            

        if ('dead' in self.state):
            self.frame_count1=min(len(self.animation_frames9)-1,self.frame_count1)
            if self.frame_count1==len(self.animation_frames9)-1:
                self.computer=None
                self.exist=False
        if self.health<=0:
            if 'dead' not in self.state:
                self.frame_count1=0
            self.state='dead-'+self.dir
            self.background_state=self.state
            # print(3)
            
            # print(self.state)
        if self.health_decrement>0:
            self.health_timer+=1
            self.healthy+=5
            if self.health_timer==20:
                self.health_decrement=0
                self.health_timer=0
                self.healthy=0
        if self.player:
            pass
            self.char_x=min(max(0,self.char_x),875)


class Goblin(Character):
    def __init__(self,screen,x,WASD=False,speed=0,state='right',name=None,computer=None,health=100,attack=20,bullet_speed=0,player=False,bullet=True,attack_freq=3,new_factor=64,bullet_attack=100,summit=False):
        Character.__init__(self,screen,x,WASD,speed,state,name,computer,health,attack,player,bullet,attack_freq)
        self.spritesheet = pygame.image.load("Monsters_Creatures_Fantasy/Goblin/Run.png")
        print(self.spritesheet.get_width(),self.spritesheet.get_height())
        self.flipped_sprite_image = pygame.transform.flip(self.spritesheet, True, False)
        self.spritesheet1 = pygame.image.load("Monsters_Creatures_Fantasy/Goblin/Idle.png")
        self.flipped_sprite_image1 = pygame.transform.flip(self.spritesheet1, True, False)
        # self.spritesheet2 = pygame.image.load("PNGExports/ShootGun1.png")
        self.spritesheet2 = pygame.image.load("Monsters_Creatures_Fantasy/Goblin/Attack.png")
        self.flipped_sprite_image2 = pygame.transform.flip(self.spritesheet2, True, False)
        self.spritesheet3 = pygame.image.load("PNGExports/JumpAndFall.png")
        self.flipped_sprite_image3 = pygame.transform.flip(self.spritesheet3, True, False)
        self.spritesheet4 = pygame.image.load("Monsters_Creatures_Fantasy/Goblin/Death.png")
        self.flipped_sprite_image4 = pygame.transform.flip(self.spritesheet4, True, False)
        self.spritesheet5 = pygame.image.load("PNGExports/GroundCombo3.png")
        self.flipped_sprite_image5 = pygame.transform.flip(self.spritesheet5, True, False)
        self.spritesheet6 = pygame.image.load("PNGExports/GroundCombo3.png")
        self.flipped_sprite_image6 = pygame.transform.flip(self.spritesheet6, True, False)
        self.FRAME_WIDTH, self.FRAME_HEIGHT = 150, 150
        new_factor= (300,300) #96
        self.animation_frames=[pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(8)]
        self.animation_frames1 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(7,-1,-1)]
        self.animation_frames2 = [pygame.transform.scale(self.spritesheet1.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(4)]
        self.animation_frames3 = [pygame.transform.scale(self.flipped_sprite_image1.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(3,-1,-1)]
        self.animation_frames4 = [pygame.transform.scale(self.spritesheet2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(8)] #+ [pygame.transform.scale(self.spritesheet5.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(14)]
        self.animation_frames7 = [pygame.transform.scale(self.flipped_sprite_image2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(7,-1,-1)] #+ [pygame.transform.scale(self.flipped_sprite_image5.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(13,-1,-1)]
        # self.animation_frames5 = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 6*97, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(10)]
        # self.animation_frames6 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 6*97, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(9,-1,-1)]
        
        self.animation_frames8 = [pygame.transform.scale(self.spritesheet4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(4)]
        self.animation_frames9 = [pygame.transform.scale(self.flipped_sprite_image4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(3,-1,-1)]
        # self.animation_frames10 = [pygame.transform.scale(self.spritesheet6.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(4)]
        # self.animation_frames11 = [pygame.transform.scale(self.flipped_sprite_image6.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(3,-1,-1)]
        self.offset=84 +60+40 #+120+20
        self.FRAME_WIDTH, self.FRAME_HEIGHT = new_factor
        self.attack_e=600
        self.flag=True
        self.bullets=[]
        self.bullet_speed=bullet_speed
        self.bullet_attack=bullet_attack
        self.summit=summit
        self.gr=False
        self.actual_x1=1230
        self.actual_x2=930 * 2 +300
        self.sr=False
        self.cr=0
        self.sr1=14
        self.sr2=25
        self.sr3=0


    def health_bar(self):
         if self.health>=0:
                text_surface = pygame.font.Font('freesansbold.ttf',20).render(self.name1, True, (255,100,100))
                text_rect = text_surface.get_rect(center=(self.char_x+28+120, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-40 + 110))  # Center text on screen
                self.SCREEN.blit(text_surface, text_rect)
                if self.health_decrement>0:
                    text_surface = pygame.font.Font('freesansbold.ttf',20).render(str(self.health_decrement), True, (255,0,0))
                    text_rect = text_surface.get_rect(center=(self.char_x+28+120, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+ 110-self.healthy))  # Center text on screen
                    self.SCREEN.blit(text_surface, text_rect)
                pygame.draw.rect(self.SCREEN, (0,0,0), (self.char_x+14+120, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-22+ 110, 34, 14))
                
                pygame.draw.rect(self.SCREEN, (0,255,0), (self.char_x+16+120, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+ 110, (30/self.MAX_HEALTH)*self.health, 10))


    def frequency_manager(self,p,attack_freq,attackers):
        if 'attack' in self.state:
            if p%self.attack_freq==0:
                self.frame_count1+=1
                
                if self.frame_count1==7:
                    for attacker in attackers:
                        self.collision(attacker)
                    # self.collision(P4)
        elif p%3==0:
            self.frame_count1+=1
        if len(attackers)==0:
            self.computer=None
        if p%200==0 and not self.player:
            if 'attack' not in self.state and 'dead' not in self.state and len(attackers)>0:
                    self.frame_count1=0
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'
        for i in range(len(attackers)):
            for bullet in self.bullets:
                bullet.collision(attackers[i])
                
    def collision(self,other):
        print(abs(self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)))
        c=self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)
        if (abs(self.offset-other.offset)<=40 and abs(c)<=60):
            if 'attack' in self.state and (other.exist) and ((self.dir=='right' and c<0)or (self.dir=='left' and c>0)):
                other.health-=self.attack
                other.health_decrement+=self.attack
                if not self.player:
                    self.flag=False
                if other.health<=0:
                    self.computer=None

    def draw(self):
        Hobbit.draw(self)
        # print(1)
        if 'attack' in self.state:
            if self.frame_count1==6: 
                self.flag=True
            if self.frame_count1==5:

                if self.flag:
                    b=Bullet(self.SCREEN,"goli.png",self.char_x+60,self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset+80,speed=self.bullet_speed,dir=self.dir,attack=self.bullet_attack,player=self.player,range=(30,40))
                    self.bullets.append(b)
                    self.flag=False
                

        for bullet in self.bullets:
            bullet.draw()


class EyeMonster(Character):
    def __init__(self,screen,x,WASD=False,speed=0,state='right',name=None,computer=None,health=100,attack=20,bullet_speed=0,player=False,bullet=False,attack_freq=3,summit=False):
        Character.__init__(self,screen,x,WASD,speed,state,name,computer,health,attack,player,bullet,attack_freq)
        self.spritesheet = pygame.image.load("Monsters_Creatures_Fantasy/Flying eye/Flight.png")
        print(self.spritesheet.get_width(),self.spritesheet.get_height())
        self.flipped_sprite_image = pygame.transform.flip(self.spritesheet, True, False)
        # self.spritesheet1 = pygame.image.load("Monsters_Creatures_Fantasy/Flying eye/Idle.png")
        # self.flipped_sprite_image1 = pygame.transform.flip(self.spritesheet1, True, False)
        # self.spritesheet2 = pygame.image.load("PNGExports/ShootGun1.png")
        self.spritesheet2 = pygame.image.load("Monsters_Creatures_Fantasy/Flying eye/Attack.png")
        self.flipped_sprite_image2 = pygame.transform.flip(self.spritesheet2, True, False)
        self.spritesheet3 = pygame.image.load("PNGExports/JumpAndFall.png")
        self.flipped_sprite_image3 = pygame.transform.flip(self.spritesheet3, True, False)
        self.spritesheet4 = pygame.image.load("Monsters_Creatures_Fantasy/Flying eye/Death.png")
        self.flipped_sprite_image4 = pygame.transform.flip(self.spritesheet4, True, False)
        self.spritesheet5 = pygame.image.load("PNGExports/GroundCombo3.png")
        self.flipped_sprite_image5 = pygame.transform.flip(self.spritesheet5, True, False)
        self.spritesheet6 = pygame.image.load("PNGExports/GroundCombo3.png")
        self.flipped_sprite_image6 = pygame.transform.flip(self.spritesheet6, True, False)
        self.FRAME_WIDTH, self.FRAME_HEIGHT = 150, 150
        new_factor= (300,300) #96
        self.animation_frames=[pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(8)]
        self.animation_frames1 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(7,-1,-1)]
        self.animation_frames2 = self.animation_frames
        self.animation_frames3 =  self.animation_frames1
        self.animation_frames4 = [pygame.transform.scale(self.spritesheet2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(8)] #+ [pygame.transform.scale(self.spritesheet5.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(14)]
        self.animation_frames7 = [pygame.transform.scale(self.flipped_sprite_image2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(7,-1,-1)] #+ [pygame.transform.scale(self.flipped_sprite_image5.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(13,-1,-1)]
        # self.animation_frames5 = [pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 6*97, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(10)]
        # self.animation_frames6 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 6*97, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(9,-1,-1)]
        
        self.animation_frames8 = [pygame.transform.scale(self.spritesheet4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(4)]
        self.animation_frames9 = [pygame.transform.scale(self.flipped_sprite_image4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(3,-1,-1)]
        # self.animation_frames10 = [pygame.transform.scale(self.spritesheet6.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(4)]
        # self.animation_frames11 = [pygame.transform.scale(self.flipped_sprite_image6.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
        #                     for x in range(3,-1,-1)]
        self.offset=84 +60+40 -40 #+120+20
        self.FRAME_WIDTH, self.FRAME_HEIGHT = new_factor
        self.attack_e=600
        self.flag=True
        self.bullets=[]
        self.bullet_speed=bullet_speed
        self.summit=summit
        self.gr=False
        self.actual_x1=1230
        self.actual_x2=930 * 2 +300
        self.sr=False
        self.cr=0
        self.sr1=14
        self.sr2=25
        self.sr3=0


    def health_bar(self):
         if self.health>=0:
                text_surface = pygame.font.Font('freesansbold.ttf',20).render(self.name1, True, (255,100,100))
                text_rect = text_surface.get_rect(center=(self.char_x+28+120, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-40 + 110))  # Center text on screen
                self.SCREEN.blit(text_surface, text_rect)
                if self.health_decrement>0:
                    text_surface = pygame.font.Font('freesansbold.ttf',20).render(str(self.health_decrement), True, (255,0,0))
                    text_rect = text_surface.get_rect(center=(self.char_x+28+120, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+ 110-self.healthy))  # Center text on screen
                    self.SCREEN.blit(text_surface, text_rect)
                pygame.draw.rect(self.SCREEN, (0,0,0), (self.char_x+14+120, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-22+ 110, 34, 14))
                
                pygame.draw.rect(self.SCREEN, (0,255,0), (self.char_x+16+120, self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset-20+ 110, (30/self.MAX_HEALTH)*self.health, 10))


    def frequency_manager(self,p,attack_freq,attackers):
        if 'attack' in self.state:
            if p%self.attack_freq==0:
                self.frame_count1+=1
                
                if self.frame_count1==7:
                    for attacker in attackers:
                        self.collision(attacker)
                    # self.collision(P4)
        elif p%3==0:
            self.frame_count1+=1
        if len(attackers)==0:
            self.computer=None



class DarkFairy(Character):
    def __init__(self,screen,x,WASD=False,speed=0,state='left',name=None,computer=None,health=100,attack=20,bullet_speed=0,player=False,bullet=False,attack_freq=3,arr=[0,0,1]):
        Character.__init__(self,screen,x,WASD,speed,state,name,computer,health,attack,player,bullet,attack_freq)
        self.spritesheet = pygame.image.load("darkfairy_phase2/spritesheets/darkfairy_phase2_idle.png")
        print(self.spritesheet.get_width(),self.spritesheet.get_height())
        self.flipped_sprite_image = pygame.transform.flip(self.spritesheet, True, False)
        self.spritesheet1 = pygame.image.load("darkfairy_phase1/spritesheets/darkfairy_phase1_idle.png")
        self.flipped_sprite_image1 = pygame.transform.flip(self.spritesheet1, True, False)
        # self.spritesheet2 = pygame.image.load("PNGExports/ShootGun1.png")
        self.spritesheet2 = pygame.image.load("darkfairy_phase1/spritesheets/darkfairy_phase1_closeattack.png")
        print(self.spritesheet2.get_width(),self.spritesheet2.get_height())
        self.flipped_sprite_image2 = pygame.transform.flip(self.spritesheet2, True, False)
        self.spritesheet2,self.flipped_sprite_image2=self.flipped_sprite_image2,self.spritesheet2
        self.spritesheet3 = pygame.image.load("darkfairy_phase1/spritesheets/darkfairy_phase1_shieldhit.png")
        self.flipped_sprite_image3 = pygame.transform.flip(self.spritesheet3, True, False)
        self.spritesheet4 = pygame.image.load("darkfairy_phase2/spritesheets/darkfairy_phase2_death.png")
        self.flipped_sprite_image4 = pygame.transform.flip(self.spritesheet4, True, False)
        self.spritesheet5 = pygame.image.load("PNGExports/GroundCombo3.png")
        self.flipped_sprite_image5 = pygame.transform.flip(self.spritesheet5, True, False)
        self.spritesheet6 = pygame.image.load("darkfairy_phase1/spritesheets/darkfairy_phase1_castspell.png")
        self.flipped_sprite_image6 = pygame.transform.flip(self.spritesheet6, True, False)
        self.spritesheet7 = pygame.image.load("darkfairy_phase1/spritesheets/darkfairy_phase1_spell.png")
        self.FRAME_WIDTH, self.FRAME_HEIGHT = 64, 64
        new_factor= (128,128) #96
        self.animation_frames=[pygame.transform.scale(self.spritesheet.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(2)]
        self.animation_frames1 = [pygame.transform.scale(self.flipped_sprite_image.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(1,-1,-1)]
        self.animation_frames2 = [pygame.transform.scale(self.spritesheet1.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(8)]
        self.animation_frames3 = [pygame.transform.scale(self.flipped_sprite_image1.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(7,-1,-1)]
        self.animation_frames4 = [pygame.transform.scale(self.spritesheet2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(7,-1,-1)] + [pygame.transform.scale(self.spritesheet2.subsurface((7*64+ x * self.FRAME_WIDTH, 64, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(0,-1,-1)] 
        self.animation_frames7 = [pygame.transform.scale(self.flipped_sprite_image2.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(8)] + [pygame.transform.scale(self.flipped_sprite_image2.subsurface((x * self.FRAME_WIDTH, 64, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(1)]
        self.animation_frames5 = [pygame.transform.scale(self.spritesheet3.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(3)]
        self.animation_frames6 = self.animation_frames5
        
        self.animation_frames8 = [pygame.transform.scale(self.spritesheet4.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(8)]+[pygame.transform.scale(self.spritesheet4.subsurface((x * self.FRAME_WIDTH, 64, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(8)]
        self.animation_frames9 = self.animation_frames8
        self.animation_frames10 = [pygame.transform.scale(self.spritesheet6.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(7)]
        self.animation_frames11 = [pygame.transform.scale(self.flipped_sprite_image6.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(6,-1,-1)]
        self.animation_frames12=[pygame.transform.scale(self.spritesheet7.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(7)]
        self.offset=84 +60+20 #+120+20
        
        self.attack_e=800
        self.flag=True
        self.bullets=[]
        self.bullet_speed=bullet_speed
        self.counter=0
        self.myflag=True
        self.attackcool1=0
        self.attackcool2=0
        self.attackcool3=0
        self.bullet=False
        self.arr=arr
        # self.owl=EyeMonster(self.SCREEN,self.char_x,speed=10,name='P3',computer=self.computer,attack_freq=1,health=300)
        self.owl=None
        if self.arr[0]==1:
            self.spritesheet6 = pygame.image.load("darkfairy_phase2/spritesheets/darkfairy_phase2_explosion.png")
            self.flipped_sprite_image6 = pygame.transform.flip(self.spritesheet6, True, False)
            self.animation_frames10 = [pygame.transform.scale(self.spritesheet6.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(4)]
            self.animation_frames11 = [pygame.transform.scale(self.flipped_sprite_image6.subsurface((x * self.FRAME_WIDTH, 0, self.FRAME_WIDTH, self.FRAME_HEIGHT)),new_factor)
                            for x in range(3,-1,-1)]
        
        if self.arr[1]==1:
            self.bullet=True
        self.FRAME_WIDTH, self.FRAME_HEIGHT = new_factor



    def state_control(self):
        keys = pygame.key.get_pressed()
        self.counter+=1
        if not 'dead' in self.state:
            if not self.WASD:
                if keys[pygame.K_RIGHT]:  # Right arrow key held down
                    if self.player:
                        if (self.state!='right' and 'up' not in self.state): self.frame_count=0; self.speed_x=0;self.g=1;self.speed=0 # Right arrow key held down
                    else:
                        if (self.state!='right'): self.frame_count=0
                    if self.counter%3==0:
                        self.frame_count += 1
                    self.frame_count1=0
                    self.state='right'
                    self.background_state='right'
                    self.dir='right'
                    self.char_x+=self.speed

                    
                        
                    # self.actual_x+=self.speed
                    # print(self.char_x,self.speed)
                    # print("by")
                elif keys[pygame.K_LEFT]:
                    if self.player:
                        if (self.state!='left' and 'up' not in self.state): self.frame_count=0;self.speed_x=0;self.g=1;self.speed=0
                    else:
                        if (self.state!='left'): self.frame_count=0
                    if self.counter%2==0:
                        self.frame_count += 1
                    self.state='left'
                    self.frame_count1=0
                    self.char_x-=self.speed
                    self.background_state='left'
                    self.dir='left'
                    # self.actual_x-=self.speed
                    # print('bye')
                elif keys[pygame.K_DOWN] and self.attackcool2==0:
                    if('duck' not in self.state):self.frame_count1=0;self.attackcool2=2
                    self.frame_count=0
                    self.state='duck-'+self.dir
                    self.background_state='duck'
                    
                elif self.state=='right':
                    self.state='idle_right'
                    self.dir='right'
                    self.background_state='idle_right'
                elif self.state=='left':
                    self.state='idle_left'
                    self.background_state='idle_left'
                    self.dir='left'
                if keys[pygame.K_UP] and self.attackcool1==0:
                    self.state='up-'+self.dir
                    # print(self.char_x)
                    if self.f==0:
                        self.frame_count =0
                        self.frame_count1=0
                        # self.state='up-'
                        self.f+=1
                        self.attackcool1=2
                        # self.offset-=40
                        
                if keys[pygame.K_SPACE] and self.attackcool3==0:
                    if('attack' not in self.state):
                        self.frame_count1=0
                        if self.arr[1]==1:
                             b=Bullet(self.SCREEN,"goli.png",self.char_x+60,self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset-80,speed=self.bullet_speed,dir=self.dir,attack=200,player=self.player,range=(100,60))
                             b.bullet=EyeMonster(self.SCREEN,700,speed=10,WASD=True,name='P3',computer=None,attack_freq=1,health=300).animation_frames2[0]
                             b.flip=pygame.transform.flip(b.bullet, True, False)
                             self.bullets.append(b)
                             self.computer.health-=100
                             self.computer.health_decrement+=100
                        self.attackcool3=2
                            
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'

            elif self.computer!=None and not self.player:
                other=self.computer
                c=self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)
                if self.myflag:
                    if abs(c)>=200:
                        if 'attack' not in self.state:
                            if c<0:
                                if abs(c)<=self.attack_e:
                                    if (self.state!='right'): self.frame_count=0 # Right arrow key held down
                                    if self.counter%3==0:
                                        self.frame_count += 1
                                    self.frame_count1=0
                                    self.state='right'
                                    self.background_state='right'
                                    self.dir='right'
                                    self.char_x+=self.speed
                                else:
                                    self.dir='right'
                                    self.state='idle_right'
                            else:
                                if abs(c)<=self.attack_e:
                                    if (self.state!='left'): self.frame_count=0
                                    if self.counter%3==0:
                                        self.frame_count += 1
                                    self.state='left'
                                    self.frame_count1=0
                                    self.char_x-=self.speed
                                    self.background_state='left'
                                    self.dir='left'
                                else:
                                    self.dir='left'
                                    self.state='idle_left'

                            
                    else:
                        if abs(c)>80:
                            
                            if 'duck' not in self.state and 'dead' not in self.state:
                                self.frame_count1=0
                                self.frame_count=0
                                self.state='duck-'+self.dir
                                self.background_state='duck'
                        else:
                            print(self.dir)
                            if 'attack' not in self.state and 'dead' not in self.state:
                                self.frame_count1=0
                                self.frame_count=0
                                self.state='attack-'+self.dir
                                self.background_state='attack'
                            
                
                # if self.state=='right':
                #     self.state='idle_right'
                #     self.dir='right'
                #     self.background_state='idle_right'
                # elif self.state=='left':
                #     self.state='idle_left'
                #     self.background_state='idle_left'
                #     self.dir='left'

                
            else:
                if keys[pygame.K_d]:  # Right arrow key held down
                    if (self.state!='right'): self.frame_count=0 # Right arrow key held down
                    if self.counter%2==0:
                        self.frame_count += 1
                    self.frame_count1=0
                    self.state='right'
                    self.background_state='right'
                    self.dir='right'
                    self.char_x+=self.speed
                    # self.actual_x+=self.SPEED
                    # print(self.char_x,self.speed)
                    # print("by")
                elif keys[pygame.K_a]:
                    if (self.state!='left'): self.frame_count=0
                    if self.counter%2==0:
                        self.frame_count += 1
                    self.state='left'
                    self.frame_count1=0
                    self.char_x-=self.speed
                    self.background_state='left'
                    self.dir='left'
                    # self.actual_x-=self.SPEED
                    
                elif self.state=='right':
                    self.state='idle_right'
                    self.dir='right'
                    self.background_state='idle_right'
                elif self.state=='left':
                    self.state='idle_left'
                    self.background_state='idle_left'
                    self.dir='left'
                if keys[pygame.K_w]:
                    self.state='up-'+self.dir
                    # print(self.char_x)
                    if self.f==0:
                        self.frame_count =0
                        self.frame_count1=0
                        # self.state='up-'
                        self.f+=1
                        # self.offset-=40
                        
                elif keys[pygame.K_x]:
                    self.frame_count1=0
                    self.frame_count=0
                    self.state='attack-'+self.dir
                    self.background_state='attack'
                
                
                
            
        if(self.f!=0 and not self.player):
             self.offset-=self.offset_speed
             self.offset_speed-=self.gravity
             self.f+=1
             
             if(self.f==14):
                 self.f=0
                 if (not keys[pygame.K_RIGHT] and not keys[pygame.K_LEFT]):
                    self.state='idle_'+self.dir
                    self.background_state=self.state
                 self.offset_speed=30
                #  print(self.state,self.f)
                    # print("hi")
        if(self.g!=0 and ('idle' not in self.state) and self.player):
             self.speed_x+=1
             self.g+=1
             print(self.speed_x,self.SPEED,self.g)
             if(self.speed_x>=self.SPEED):
                 self.speed_x=self.SPEED
                 self.g=0

        if ('attack' in self.state) and self.frame_count1>len(self.animation_frames4):
            self.state='idle_'+self.dir
            self.background_state=self.state
            self.frame_count1=0
            self.attackcool3=2

        if ('duck' in self.state) :
            if self.frame_count1>7:
                self.state='idle_'+self.dir
                self.background_state=self.state
                self.frame_count1=0
                self.attackcool2=2
            else:
                if self.frame_count1==6:
                    self.computer.health-=75
                    self.computer.health_decrement+=75
        if ('up' in self.state and self.player):
            if self.frame_count1>9:
                self.state='idle_'+self.dir
                self.background_state=self.state
                self.frame_count1=0
                self.attackcool1=2
        if self.attackcool1>=2:
            self.attackcool1+=1
            if self.attackcool1==50:
                self.attackcool1=0
                self.f=0
        if self.attackcool2>=2:
            self.attackcool2+=1
            if self.attackcool2==50:
                self.attackcool2=0
                self.f=0
        if self.attackcool3>=2:
            self.attackcool3+=1
            if self.attackcool3==50:
                self.attackcool3=0
                self.f=0
        print(self.attackcool1,'bello',self.state)
        # if ('up' in self.state) and self.frame_count1>3:
        #     self.state='idle_'+self.dir
        #     self.background_state=self.state
        #     self.frame_count1=0
        if self.myflag==False:
            print(self.frame_count1,'bye')
            if self.frame_count1>3:
                self.myflag=True
        if ('dead' in self.state):
            self.frame_count1=min(len(self.animation_frames9)-1,self.frame_count1)
            if self.frame_count1==len(self.animation_frames9)-1:
                self.computer=None
                self.exist=False
        if self.health<=0:
            if 'dead' not in self.state:
                self.frame_count1=0
            self.state='dead-'+self.dir
            self.background_state=self.state
            # print(3)
            
            # print(self.state)
        if self.health_decrement>0:
            self.health_timer+=1
            self.healthy+=5
            if self.health_timer==20:
                self.health_decrement=0
                self.health_timer=0
                self.healthy=0
        if self.player:
            pass
            self.char_x=min(max(0,self.char_x),875)
            # self.actual_x=max(0,self.actual_x)
            # if self.actual_x==0:
            #     self.char_x=0
        # if self.player:
        #     print(self.actual_x,'hi',self.char_x)

    def draw(self):
        self.state_control()
        
        if self.exist:   

            if self.state=='left':
                self.SCREEN.blit(self.animation_frames1[self.frame_count % len(self.animation_frames1)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset))
            elif self.state=='right':
                self.SCREEN.blit(self.animation_frames[self.frame_count % len(self.animation_frames)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset))
            elif self.state=='attack-right':
                self.SCREEN.blit(self.animation_frames4[self.frame_count1 % len(self.animation_frames4)], ( (self.char_x+48), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset))
            elif self.state=='attack-left':
                self.SCREEN.blit(self.animation_frames7[self.frame_count1 % len(self.animation_frames7)], ( (self.char_x-48), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset))
            elif self.state=='idle_right':
                if self.name=='BOSS':
                    print(1,self.char_x)
                self.SCREEN.blit(self.animation_frames2[self.frame_count1 % len(self.animation_frames2)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset))
            elif self.state=='dead-right':
                self.SCREEN.blit(self.animation_frames8[self.frame_count1 % len(self.animation_frames8)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset))
            elif self.state=='dead-left':
                self.SCREEN.blit(self.animation_frames9[self.frame_count1 % len(self.animation_frames9)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset))
            elif self.state=='duck-right':
                self.SCREEN.blit(self.animation_frames10[self.frame_count1 % len(self.animation_frames10)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset))
            elif self.state=='duck-left':
                self.SCREEN.blit(self.animation_frames11[self.frame_count1 % len(self.animation_frames11)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset))
            
            elif self.state=='idle_left':
                self.SCREEN.blit(self.animation_frames3[self.frame_count1 % len(self.animation_frames3)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset))
            elif self.state=='up-right':
                self.SCREEN.blit(self.animation_frames5[self.frame_count1 % len(self.animation_frames5)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset))
            elif self.state=='up-left':
                self.SCREEN.blit(self.animation_frames6[self.frame_count1 % len(self.animation_frames6)], ( (self.char_x), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2 + self.offset))

            self.health_bar()
            if 'duck' in self.state:
                if self.computer.name=='BOSS':
                    self.SCREEN.blit(self.animation_frames12[self.frame_count1 % len(self.animation_frames12)], ( (self.computer.char_x+55), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset-110))
                elif self.computer.name=='TeleBoss':
                     if self.arr[0]==0:
                        self.SCREEN.blit(self.animation_frames12[self.frame_count1 % len(self.animation_frames12)], ( (self.computer.char_x+40), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset-55))
                else:
                    self.SCREEN.blit(self.animation_frames12[self.frame_count1 % len(self.animation_frames12)], ( (self.computer.char_x-30), self.HEIGHT // 2 - self.FRAME_HEIGHT // 2+self.offset-30))
            
            for bullet in self.bullets:
                bullet.draw()

    def collision(self,other):
        # print(abs(self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)))
        # print(abs(self.offset-other.offset ),'hi')
        c=self.char_x+(self.FRAME_WIDTH//2) -other.char_x-(other.FRAME_WIDTH//2)
        if (abs(self.offset-other.offset )<=40 and abs(c)<=80):
            if 'attack' in self.state and (other.exist) and ((self.dir=='right' and c<0)or (self.dir=='left' and c>0)):
                other.health-=self.attack
                other.health_decrement+=self.attack
                # print(other.name,other.health_decrement)
                if other.health<=0:
                    self.computer=None
    def frequency_manager(self, p, attack_freq, attackers):
        Character.frequency_manager(self,p, attack_freq, attackers)
        for i in range(len(attackers)):
            for bullet in self.bullets:
                bullet.collision(attackers[i])




    










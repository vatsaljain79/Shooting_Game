import pygame
class LevelMaker:
    def __init__(self, Screen, background,background1,attackers, player,name="Level" ,attack_freq=3):
        self.SCREEN = Screen
        self.background = background
        self.background1 = background1
        self.attackers = attackers
        self.name = name
        self.WIDTH = 930
        self.player = player
        self.exit=False
        self.attack_freq=attack_freq
        
    def run(self):
        background_x=0
        running= True
        FPS=25
        clock = pygame.time.Clock()
        p=0

        while running:
            # WIDTH=800
            self.SCREEN.fill((255, 255, 255))
            self.SCREEN.blit(self.background1,(background_x,0))
            self.SCREEN.blit(self.background,(background_x + self.WIDTH,0))
            self.SCREEN.blit(self.background,(background_x + self.WIDTH + self.WIDTH,0))
            #self.SCREEN.blit(self.background,(background_x - self.WIDTH ,0))
            text_surface = pygame.font.Font('freesansbold.ttf',50).render("H", True, (255,0,0))
            
            # Blit text surface onto screen
            # text_rect = text_surface.get_rect(center=(56, GROUND))  # Center text on screen
            # SCREEN.blit(text_surface, text_rect)
            # SCREEN.blit(P1.animation_frames2[0],(-40,HEIGHT//2 -70))
            self.player.draw()
            for attacker in self.attackers:
                attacker.draw()
            
            # SCREEN.blit(P7.bullet,(100,200))
            # P4.SCREEN.blit(P4.new_surface,(200,200))
            background_x,back_speed=self.player.get_background(self.player.SPEED,background_x)
            # print(back_speed)
            if back_speed!=0: 
                for attacker in self.attackers:
                    attacker.char_x-=back_speed
                    if attacker.bullet:
                        print(attacker.name)
                        for bullet in attacker.bullets:
                            bullet.x-=back_speed

            # P3.draw()
            pygame.display.flip()
            
            # Handle events
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                # if event.type == pygame.KEYDOWN:
                #     if event.key == pygame.K_RIGHT:
                #         frame_count+=1
            
            
            # Animation control
            self.player.frequency_manager(p,2,self.attackers)

            # P5.frequency_manager(p,3,[P4])
            # P6.frequency_manager(p,3,[P4])
            # P7.frequency_manager(p,3,[P4])
            # P8.frequency_manager(p,3,[P4])
            # P9.frequency_manager(p,3,[P4])
            for attacker in self.attackers:
                attacker.frequency_manager(p,self.attack_freq,[self.player])
            for attacker in self.attackers[::]:
                if not attacker.exist:
                    self.attackers.remove(attacker)
            #print(len(self.attackers))
            # if p % 5==0:
            #     P1.frame_count1 += 1
            #     P2.frame_count1+=1
            #     P3.frame_count1+=1
                
            p+=1
            if (self.player.HEIGHT // 2 - self.player.FRAME_HEIGHT // 2 + self.player.offset)>=650:
                self.player.exist=False
            keys=pygame.key.get_pressed()
            if keys[pygame.K_ESCAPE]:
                running=False
                self.exit=self.player
                return self.exit
            if self.player.exist and len(self.attackers)==0:
                self.exit=self.player
                running=False
                return self.exit
            if not self.player.exist:
                self.exit=False
                return self.exit
            
            # print(p)
            # print(P5.animation_frames7)
            clock.tick(FPS)



            
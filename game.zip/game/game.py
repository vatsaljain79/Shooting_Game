import pygame
import sys
from start import main
from secpage import second
from vid1 import vid1
from vid2 import vid2
from vid3 import vid3
from vid4 import vid4
from vid5 import vid5
from sel1 import sel
from sel3 import sel1
# Initialize Pygame
pygame.init()
WIDTH, HEIGHT = 930,650
# OrI=pygame.display.set_mode((1000, 700))
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
from Character import *
from LevelMaker import LevelMaker

while True:
    name=main()
    xp=0
    health=0
    attack=0
    print(name)
    second(name)
    c=vid1()
    if c==1:
        xp+=2
    background = pygame.image.load("forest.png")
    background1 = pygame.image.load("forest_text.png")
    pygame.mixer.music.load("fight.mp3")
    pygame.mixer.music.play(loops=-1) 
    player=Hobbit(SCREEN,0,speed=20,name=name,health=1000,player=True,attack_freq=1)
    m1=Mushroom(SCREEN,700,speed=7,WASD=True,name='P3',computer=player,attack_freq=3,health=300)
    m2=Mushroom(SCREEN,1400,speed=7,WASD=True,name='P3',computer=player,attack_freq=3,health=300)
    g1=Goblin(SCREEN,1000,speed=10,WASD=True,name='P3',computer=player,attack_freq=1,bullet=True,bullet_speed=15)
    g2=Goblin(SCREEN,1500,speed=10,WASD=True,name='P3',computer=player,attack_freq=1,bullet=True,bullet_speed=15)
    boss=MartialHero(SCREEN,2300,speed=10,WASD=True,name='P2',computer=player,health=500)
    level1=LevelMaker(SCREEN,background,background1,[m1,m2,g1,g2,boss],player)
    player=level1.run()
    if player==False:
        text_surface = pygame.font.Font('freesansbold.ttf',50).render("GAME OVER !!!!!!", True, (255,255,255))
        text_rect = text_surface.get_rect(center=(450, 200))  # Center text on screen
        start_time = pygame.time.get_ticks() 
        clock1 = pygame.time.Clock()
        while True:
            SCREEN.blit(text_surface, text_rect)
            print("GAME OVER !!!!!!")
            if pygame.time.get_ticks() - start_time >= 2000:
                break
            pygame.display.flip()
            clock1.tick(25)
       
        
        continue
        
    health=player.HEALTH
    attack=player.attack

    flag,health,attack=sel("Bullet",xp,health,attack)
    c=vid4()
    if c==1:
        xp+=2
    background = pygame.image.load("castle2.png")
    background1 = pygame.image.load("castle2_text.png")
    if flag:
        player=Hobbit_with_Bullet(SCREEN,0,speed=20,name='P1',health=2000,player=True,bullet=True,bullet_speed=20,attack_freq=1)
    # player.health=health
    # player.HEALTH=health
    player.name1=name
    player.attack=attack
    m1=Mushroom(SCREEN,700,speed=10,WASD=True,name='P3',computer=player,attack_freq=3,health=300)
    m2=Mushroom(SCREEN,1400,speed=10,WASD=True,name='P3',computer=player,attack_freq=3,health=300)
    g1=Skeleton(SCREEN,1000,speed=15,WASD=True,name='Skeleton',computer=player,attack_freq=2,attack=40,health=500)
    g2=Skeleton(SCREEN,1500,speed=15,WASD=True,name='Skeleton',computer=player,attack_freq=2,attack=40,health=500)
    g1.shield=True
    g2.shield=True
    boss=BOSS(SCREEN,2300,speed=15,WASD=True,name='BOSS',computer=player,health=2000,attack=90,attack_freq=1,bullet_speed=20,bullet=True)
    for i in [m1,m2,g1,g2,boss,player]:
        i.offset+=38
    pygame.mixer.music.load("fight.mp3")
    pygame.mixer.music.play(loops=-1) 
    level2=LevelMaker(SCREEN,background,background1,[m1,m2,g1,g2,boss],player)
    player=level2.run()
    if player==False:
        text_surface = pygame.font.Font('freesansbold.ttf',50).render("GAME OVER !!!!!!", True, (255,255,255))
        text_rect = text_surface.get_rect(center=(450, 200))  # Center text on screen
        start_time = pygame.time.get_ticks() 
        clock1 = pygame.time.Clock()
        while True:
            SCREEN.blit(text_surface, text_rect)
            print("GAME OVER !!!!!!")
            if pygame.time.get_ticks() - start_time >= 2000:
                break
            pygame.display.flip()
            clock1.tick(25)
       
        
        continue
    health=player.HEALTH
    attack=player.attack
    flag,health,attack=sel("NewCharacter",xp,health,attack)
    c=vid5()
    if c==1:
        xp+=2

    background = pygame.image.load("labf.png")
    background1 = pygame.image.load("lab_textf.png")
    # player=Hobbit_with_Bullet(SCREEN,0,speed=20,name='P1',health=2500,player=True,bullet=True,bullet_speed=20,attack_freq=1)
    if flag:
        player=BOSS(SCREEN,0,speed=20,name='BOSS',health=2000,player=True,bullet=True,bullet_speed=20,attack_freq=1,bullet_attack=300)
    # player.health=health
    # player.HEALTH=health
    player.name1=name
    player.attack=attack
    m1=EyeMonster(SCREEN,700,speed=10,WASD=True,name='P3',computer=player,attack_freq=1,health=300)
    m2=EyeMonster(SCREEN,1400,speed=10,WASD=True,name='P3',computer=player,attack_freq=1,health=300)
    g1=Skeleton(SCREEN,1000,speed=10,WASD=True,name='Skeleton',computer=player,attack_freq=2,attack=40,health=500)
    g2=Skeleton(SCREEN,1500,speed=15,WASD=True,name='Skeleton',computer=player,attack_freq=2,attack=40,health=500)
    g1.shield=True
    g2.shield=True
    boss=DarkFairy(SCREEN,2300,speed=10,WASD=True,name='DarkFairy',computer=player,health=2500,attack=100,attack_freq=3)
    for i in [m1,m2,g1,g2,boss,player]:
        i.offset-=5
    pygame.mixer.music.load("fight.mp3")
    pygame.mixer.music.play(loops=-1) 
    level3=LevelMaker(SCREEN,background,background1,[m1,m2,g1,g2,boss],player)
    player=level3.run()
    if player==False:
        text_surface = pygame.font.Font('freesansbold.ttf',50).render("GAME OVER !!!!!!", True, (255,120,0))
        text_rect = text_surface.get_rect(center=(450, 200))  # Center text on screen
        start_time = pygame.time.get_ticks() 
        clock1 = pygame.time.Clock()
        while True:
            SCREEN.blit(text_surface, text_rect)
            print("GAME OVER !!!!!!")
            if pygame.time.get_ticks() - start_time >= 2000:
                break
            pygame.display.flip()
            clock1.tick(25)
       
        
        continue
    health=player.HEALTH
    attack=player.attack
    flag,health,attack=sel("Levitate",xp,health,attack)
    c=vid3()
    if c==1:
        xp+=2

    background = pygame.image.load("summit.png")
    background1 = pygame.image.load("summit_text.png")
    # player=Hobbit_with_Bullet(SCREEN,0,speed=20,name='P1',health=2500,player=True,bullet=True,bullet_speed=20,attack_freq=1)
    player=BOSS(SCREEN,0,speed=20,name='BOSS',health=2000,player=True,bullet=True,bullet_speed=20,attack_freq=1,summit=True,attack=40)
    player.canfloat=flag
    player.name1=name
    # player.health=health
    # player.HEALTH=health
    player.attack=attack
    m1=EyeMonster(SCREEN,700,speed=10,WASD=True,name='P3',computer=player,attack_freq=1,health=300)
    m2=EyeMonster(SCREEN,1400,speed=10,WASD=True,name='P3',computer=player,attack_freq=1,health=300)
    # g1=Goblin(SCREEN,1000,speed=10,WASD=True,name='P3',computer=player,attack_freq=1,bullet=True,bullet_speed=15)
    g2=Goblin(SCREEN,1300,speed=10,WASD=True,name='P3',computer=player,attack_freq=1,bullet=True,bullet_speed=15)

    g2.shield=True
    boss=Hobbit_with_Bullet(SCREEN,2300,speed=20,WASD=True,name='bipolar',health=1500,computer=player,bullet_speed=15,bullet=True,summit=True,new_factor=100,attack_freq=1)
    for i in [m1,m2,g2,player]:
        i.offset-=38
    boss.offset-=68
    pygame.mixer.music.load("fight.mp3")
    pygame.mixer.music.play(loops=-1) 
    level4=LevelMaker(SCREEN,background,background1,[m1,m2,g2,boss],player)
    player=level4.run()
    if player==False:
        text_surface = pygame.font.Font('freesansbold.ttf',50).render("GAME OVER !!!!!!", True, (255,120,0))
        text_rect = text_surface.get_rect(center=(450, 200))  # Center text on screen
        start_time = pygame.time.get_ticks() 
        clock1 = pygame.time.Clock()
        while True:
            SCREEN.blit(text_surface, text_rect)
            print("GAME OVER !!!!!!")
            if pygame.time.get_ticks() - start_time >= 2000:
                break
            pygame.display.flip()
            clock1.tick(25)
       
        
        continue
    health=player.HEALTH
    attack=player.attack
    l=sel1("Long range thunder","Electricity Blast","Close range thunder","Owl summon","Shield",xp)
    c=vid2()
    if c==1:
        xp+=2

    background = pygame.image.load("cave2_sym.png")
    background1 = pygame.image.load("cave2_sym1.png")
    # player=Hobbit_with_Bullet(SCREEN,0,speed=20,name='P1',health=2500,player=True,bullet=True,bullet_speed=20,attack_freq=1)
    player=DarkFairy(SCREEN,0,speed=20,name='DarkFairy',health=2000,attack=100,attack_freq=3,bullet_speed=20,arr=l)
    boss=TeleBoss(SCREEN,2300,speed=0,WASD=True,name='TeleBoss',computer=player,health=2000,attack=80,attack_freq=3,bullet_speed=20,bullet=True)
    player.computer=boss
    player.name1=name
    player.player=True
    boss.offset+=30
    player.offset+=20
    pygame.mixer.music.load("fight.mp3")
    pygame.mixer.music.play(loops=-1) 
    level5=LevelMaker(SCREEN,background,background1,[boss],player)
    player=level5.run()
    if player==False:
        text_surface = pygame.font.Font('freesansbold.ttf',50).render("GAME OVER !!!!!!", True, (255,120,0))
        text_rect = text_surface.get_rect(center=(450, 200))  # Center text on screen
        start_time = pygame.time.get_ticks() 
        clock1 = pygame.time.Clock()
        while True:
            SCREEN.blit(text_surface, text_rect)
            print("GAME OVER !!!!!!")
            if pygame.time.get_ticks() - start_time >= 2000:
                break
            pygame.display.flip()
            clock1.tick(25)
       
        
        continue
    




pygame.quit()
sys.exit()

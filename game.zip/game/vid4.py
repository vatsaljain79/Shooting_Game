import cv2
import pygame
import sys
import time
def vid4():
    pygame.mixer.music.load("vid.mp3")
    pygame.mixer.music.play(loops=-1)  # Loop indefinitely
    i=0
    j=0
    k=0
    rendered_chars=""
    rendered_chars1=""
    rendered_chars2=""
    # Function to render text with typing animation
    def render_typing_text1(font, text, color, position, screen,x,i,rendered_chars):
        # global text_enter_pressed,x,i,rendered_chars
        if x%3==0 and i<len(text):
            char=text[i]
            rendered_chars += char
            rendered_text = font.render(rendered_chars, True, color)
            screen.blit(rendered_text, position)
            i+=1
        else:
            rendered_text = font.render(rendered_chars, True, color)
            screen.blit(rendered_text, position)
        return i,rendered_chars


    def render_typing_text2(font, text, color, position, screen,x,j,rendered_chars1):
        
        # global text_enter_pressed,x,j,rendered_chars1
        # for event in pygame.event.get():
        #     if event.type == pygame.KEYDOWN:
        #         if event.key == pygame.K_RETURN:  
        #             text_enter_pressed = True
        
        if x%3==0 and j<len(text):
            char=text[j]
            
            rendered_chars1 += char
            rendered_text = font.render(rendered_chars1, True, color)
            screen.blit(rendered_text, position)
            j+=1
        else:
            rendered_text = font.render(rendered_chars1, True, color)
            screen.blit(rendered_text, position)
        
        return j,rendered_chars1
            # Wait for a short duration between characters

    def render_typing_text3(font, text, color, position, screen,x,k,rendered_chars2):
        
        # global text_enter_pressed,x,k,rendered_chars2
        # for event in pygame.event.get():
        #     if event.type == pygame.KEYDOWN:
        #         if event.key == pygame.K_RETURN:  
        #             text_enter_pressed = True
        
        if x%3==0 and k<len(text):
            char=text[k]
            
            rendered_chars2 += char
            rendered_text = font.render(rendered_chars2, True, color)
            screen.blit(rendered_text, position)
            k+=1
        else:
            rendered_text = font.render(rendered_chars2, True, color)
            screen.blit(rendered_text, position)
        
        return k,rendered_chars2
    # pygame.init()
    x=0
    # Set window size
    window_size = (930, 650)
    screen = pygame.display.set_mode(window_size)
    pygame.display.set_caption("Video Player")

    # Load video
    cap = cv2.VideoCapture("castle.mp4")

    # Load speech image
    speech_left_image = pygame.image.load("speech_left.png")
    speech_left_image = pygame.transform.scale(speech_left_image, (800, 400))
    speech_left_image.set_alpha(200)

    # Load images for the bottom section
    image1 = pygame.image.load("options.png")
    image2 = pygame.image.load("options.png")
    image1 = pygame.transform.scale(image1, (375, 375))  # Scale the images as needed
    image2 = pygame.transform.scale(image2, (375, 375))

    # Define colors
    BLACK = (0, 0, 0)
    WHITE = (255, 255, 255)
    TRANSPARENT = (0, 0, 0, 0)
    HOVER_COLOR = (255, 0, 0)  # Color when hovered
    SELECTED_COLOR = (175, 0, 0)  # Color when hovered
    DEFAULT_COLOR = (255, 255, 255)  # Default color

    # Main loop
    playing = True
    clock = pygame.time.Clock()
    video_finished = False
    text_enter_pressed = False  # Flag to check if ENTER key is pressed

    # Define box parameters
    box_width = 930
    box_height = 100
    box_color = (0, 0, 0)  # Red color
    box_alpha = 0  # Initial alpha value (fully transparent)
    box_surface = pygame.Surface((box_width, box_height), pygame.SRCALPHA)  # Create surface with alpha channel
    box_surface.fill((*box_color, box_alpha))  # Fill surface with transparent red color

    # Define text parameters
    font2 = pygame.font.Font("mid.ttf", 20)
    font3 = pygame.font.Font("mid.ttf", 16)
    font = pygame.font.Font("5.otf", 35)
    text_color = WHITE
    text_alpha = 0
    text_surface = font.render("The Solitary Sanctuary - Social Anxiety", True, text_color) #CHANGEEEEE
    text_surface.set_alpha(text_alpha)
    image1_text_color = DEFAULT_COLOR
    image2_text_color = DEFAULT_COLOR
    left_selected=False
    right_selected=False
    h=-500
    while playing:
        x+=1
        ret, frame = cap.read()
        print(ret)
        flag=True
        if(h==x-35 and flag):
            return 1
        elif(h==x-35 and not flag):
            return 0

        # Read frame from video
        if ret:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    playing = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:  
                        text_enter_pressed = True
                        # Skip to the last frame of the video
                        ret=False
                        cap.set(cv2.CAP_PROP_POS_FRAMES, cap.get(cv2.CAP_PROP_FRAME_COUNT))

            # Convert frame to RGB format for Pygame
            if ret:
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                frame_pygame = pygame.image.frombuffer(frame_rgb.flatten(), cap.read()[1].shape[:2][::-1], 'RGB')

            # Clear the screen
            screen.fill(BLACK)

            # Blit frame onto Pygame screen
            screen.blit(frame_pygame, (0, 0))

            # Draw box onto Pygame screen with gradually increasing transparency
            if text_enter_pressed==True:
                box_alpha = 192
                box_surface.fill((*box_color, box_alpha))  # Update surface with new alpha value
                screen.blit(box_surface, (0, 50))  # Blit box onto screen
            elif box_alpha < 200:  # Increase alpha value until fully opaque
                box_alpha += 8  # Increase alpha gradually
                box_surface.fill((*box_color, box_alpha))  # Update surface with new alpha value
                screen.blit(box_surface, (0, 50))  # Blit box onto screen
            else:
                box_alpha += 0
                box_surface.fill((*box_color, box_alpha))  # Update surface with new alpha value
                screen.blit(box_surface, (0, 50))  # Blit box onto screen

            # Draw text onto Pygame screen with gradually increasing transparency
            if text_enter_pressed==True:
                text_alpha = 255  # Set alpha to fully opaque
                text_surface.set_alpha(text_alpha)  # Update text surface with new alpha value
                text_rect = text_surface.get_rect(center=(465, 100))  # Center text on the box
                screen.blit(text_surface, text_rect)
            elif text_alpha < 255 and not text_enter_pressed:  # Increase alpha value until fully opaque unless ENTER is pressed
                text_alpha += 8  # Increase alpha gradually
                text_surface.set_alpha(text_alpha)  # Update text surface with new alpha value
                text_rect = text_surface.get_rect(center=(465, 100))  # Center text on the box
                screen.blit(text_surface, text_rect)  # Blit text onto screen
            else:
                text_alpha = 255  # Set alpha to fully opaque
                text_surface.set_alpha(text_alpha)  # Update text surface with new alpha value
                text_rect = text_surface.get_rect(center=(465, 100))  # Center text on the box
                screen.blit(text_surface, text_rect)  # Blit text onto screen

            # Update the display
            # pygame.display.flip()

            # Cap the frame rate
            clock.tick(17)
        else:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    playing = False
                elif (event.type == pygame.MOUSEMOTION and left_selected==False and right_selected==False):
                    # Check if the mouse is over the boxes
                    pos = pygame.mouse.get_pos()
                    if 125 <= pos[0] <= 400 and 400 <= pos[1] <= 600:
                        image1_text_color = HOVER_COLOR
                    else:
                        image1_text_color = DEFAULT_COLOR
                    if 575 <= pos[0] <= 850 and 400 <= pos[1] <= 600:
                        image2_text_color = HOVER_COLOR
                    else:
                        image2_text_color = DEFAULT_COLOR
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    pos = pygame.mouse.get_pos()
                    if 125 <= pos[0] <= 400 and 400 <= pos[1] <= 600:
                        image1_text_color = HOVER_COLOR
                        image2_text_color = DEFAULT_COLOR
                        left_selected = True
                        right_selected = False
                        h=x
                    # Check if the mouse clicked on the right option
                    elif 575 <= pos[0] <= 850 and 400 <= pos[1] <= 600:
                        image1_text_color = DEFAULT_COLOR
                        image2_text_color = HOVER_COLOR
                        left_selected = False
                        right_selected = True
                        h=x
                        flag=False
                    else:
                        image1_text_color = DEFAULT_COLOR
                        image2_text_color = DEFAULT_COLOR
                        left_selected = False
                        right_selected = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:  
                        text_enter_pressed = True
                        cap.set(cv2.CAP_PROP_POS_FRAMES, cap.get(cv2.CAP_PROP_FRAME_COUNT) - 1)
                        ret=False
                
            video_finished = True  

            screen.blit(speech_left_image, (71, 55))  #CHANGEEE
            if(left_selected):
                bt1 = "Correct!!"      #CHANGEEE
                bs1 = font3.render(bt1, True, WHITE)
                screen.blit(bs1, (200, 580))     #CHANGEEE
            elif right_selected:
                bt1 = "Could have been better..."   #CHANGEEE
                bs1 = font3.render(bt1, True, WHITE)
                screen.blit(bs1, (550, 580))    #CHANGEEE
            # Render text with typing animation
            if not text_enter_pressed:
                speech_text = "When you're nervous about being around other "    #CHNAGE
                i,rendered_chars=render_typing_text1(font2, speech_text, BLACK, (240, 200), screen,x,i,rendered_chars)           #CHNAGE
                speech_text2 = "people, which might seem easier first but could keep you "    #CHNAGE
                if i==len(speech_text):
                    j,rendered_chars1=render_typing_text2(font2, speech_text2, BLACK, (190, 230), screen,x,j,rendered_chars1)           #CHNAGE
                speech_text3="from making new friends and trying new things?"    #CHNAGE
                if j==len(speech_text2):
                    k,rendered_chars2=render_typing_text3(font2, speech_text3, BLACK, (250, 260), screen,x,k,rendered_chars2)           #CHNAGE

            else:
                speech_text = "When you're nervous about being around other "   #CHNAGE
                text_surface = font2.render(speech_text, True, BLACK)  # Render the whole text directly
                text_rect = text_surface.get_rect(center=(480, 205))  # Center text on the box           #CHNAGE
                screen.blit(text_surface, text_rect)  # Blit text onto screen
                speech_text2 = "people, which might seem easier first but could keep you "   #CHNAGE
                text_surface2 = font2.render(speech_text2, True, BLACK)  # Render the whole text directly
                text_rect2 = text_surface2.get_rect(center=(480, 240))  # Center text on the box           #CHNAGE
                screen.blit(text_surface2, text_rect2)  # Blit text onto screen
                speech_text3="from making new friends and trying new things?"    #CHNAGE
                text_surface3 = font2.render(speech_text3, True, BLACK)  # Render the whole text directly
                text_rect3 = text_surface3.get_rect(center=(480, 275))  # Center text on the box           #CHNAGE
                screen.blit(text_surface3, text_rect3)  # Blit text onto screen

                # box_alpha = 192
                # box_color=(0,0,255)
                
                # box_surface.fill((*box_color, 50))  # Update surface with new alpha value
                # screen.blit(box_surface, (0, 50))

                # text_alpha = 255  # Set alpha to fully opaque
                # text_surface.set_alpha(text_alpha)  # Update text surface with new alpha value
                # text_rect = text_surface.get_rect(center=(465, 100))  # Center text on the box
                # screen.blit(text_surface, text_rect)
                print("bello")  


            # Display images in the bottom section
            
            if(k==len(speech_text3) or text_enter_pressed==True):
                screen.blit(image1, (85, 300))
                screen.blit(image2, (500, 300))
            # Render text for the bottom section with hover effect
                bottom_text = "Avoiding being around people "    #CHNAGE
                bottom_text_surface = font3.render(bottom_text, True, image1_text_color)
                screen.blit(bottom_text_surface, (130, 420))          #CHNAGE
                bottom_text2 = "so you don't have to worry "   #CHNAGE
                bottom_text2_surface = font3.render(bottom_text2, True, image1_text_color)
                screen.blit(bottom_text2_surface, (145, 455))          #CHNAGE
                bottom_text3 = "about feeling nervous."   #CHNAGE
                bottom_text3_surface = font3.render(bottom_text3, True, image1_text_color)
                screen.blit(bottom_text3_surface, (150, 490))          #CHNAGE

                bottom_text = "Taking initiative to be arnd people "     #CHNAGE
                bottom_text_surface = font3.render(bottom_text, True, image2_text_color)
                screen.blit(bottom_text_surface, (535, 410))
                bottom_text2 = "more often, even if it feels "     #CHNAGE
                bottom_text2_surface = font3.render(bottom_text2, True, image2_text_color)
                screen.blit(bottom_text2_surface, (550, 440))          #CHNAGE
                bottom_text3 = "scary at first, so you can get "     #CHNAGE
                bottom_text3_surface = font3.render(bottom_text3, True, image2_text_color)
                screen.blit(bottom_text3_surface, (555, 470))          #CHNAGE
                bottom_text4 = "more comfortable over time."     #CHNAGE
                bottom_text4_surface = font3.render(bottom_text4, True, image2_text_color)
                screen.blit(bottom_text4_surface, (565, 500))          #CHNAGE

        
        
        pygame.display.flip()

        if video_finished and not playing:
            break

    # Release video capture
    cap.release()

# Quit Pygame
# vid4()
# pygame.quit()

import pygame
import sys

# Initialize Pygame
# pygame.init()

def second(name):
    # Set up the screen

    pygame.mixer.music.load("sel2.mp3")
    pygame.mixer.music.play(loops=-1)  # Loop indefinitely

    screen_width = 930
    screen_height = 650
    screen = pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("Second Page")

    # Load background image
    background_image = pygame.image.load("secpage.png").convert()
    background_rect = background_image.get_rect()

    # Load dialog image
    dialog_image = pygame.image.load("secdialog.png").convert_alpha()
    dialog_image=pygame.transform.scale(dialog_image,(800,210))
    dialog_rect = dialog_image.get_rect()
    dialog_rect.center = (480, 120)  # Center the dialog image on the screen

    dialog_image2 = pygame.image.load("secdialog.png").convert_alpha()
    dialog_image2=pygame.transform.scale(dialog_image2,(800,210))
    dialog_rect2 = dialog_image2.get_rect()
    dialog_rect2.center = (480, 120)  # Center the dialog image on the screen

    dialog_image2 = pygame.image.load("secdialog.png").convert_alpha()
    dialog_image2=pygame.transform.scale(dialog_image2,(800,230))
    dialog_rect2 = dialog_image2.get_rect()
    dialog_rect2.center = (480, 115)  # Center the dialog image on the screen

    # Main loop
    running = True
    x=0
    i=0
    j=0
    k=0
    l=0
    rendered_chars=""
    rendered_chars1=""
    rendered_chars2=""
    rendered_chars3=""
    def render_typing_text1(font, text, color, position, screen,x,i,rendered_chars):
        # global text_enter_pressed,x,i,rendered_chars
        if x%3==0 and i<len(text):
            char=text[i]
            rendered_chars += char
            rendered_text = font.render(rendered_chars, True, color)
            screen.blit(rendered_text, position)
            i+=1
        else:
            rendered_text = font.render(rendered_chars, True, color)
            screen.blit(rendered_text, position)
        return i,rendered_chars

    def render_typing_text2(font, text, color, position, screen,x,j,rendered_chars1):
        
        # global text_enter_pressed,x,j,rendered_chars1
        if x%3==0 and j<len(text):
            char=text[j]
            
            rendered_chars1 += char
            rendered_text = font.render(rendered_chars1, True, color)
            screen.blit(rendered_text, position)
            j+=1
        else:
            rendered_text = font.render(rendered_chars1, True, color)
            screen.blit(rendered_text, position)
        return j,rendered_chars1

    def render_typing_text3(font, text, color, position, screen,x,k,rendered_chars2):
        
        # global text_enter_pressed,x,k,rendered_chars2
        if x%3==0 and k<len(text):
            char=text[k]
            
            rendered_chars2 += char
            rendered_text = font.render(rendered_chars2, True, color)
            screen.blit(rendered_text, position)
            k+=1
        else:
            rendered_text = font.render(rendered_chars2, True, color)
            screen.blit(rendered_text, position)
        return k,rendered_chars2

    def render_typing_text4(font, text, color, position, screen,x,l,rendered_chars3):
        
        # global text_enter_pressed,x,l,rendered_chars3
        if x%3==0 and l<len(text):
            char=text[l]
            
            rendered_chars3 += char
            rendered_text = font.render(rendered_chars3, True, color)
            screen.blit(rendered_text, position)
            l+=1
        else:
            rendered_text = font.render(rendered_chars3, True, color)
            screen.blit(rendered_text, position)
        return l,rendered_chars3

    BLACK = (0, 0, 0)
    WHITE = (255,255,255)
    font5 = pygame.font.Font("7.ttf", 19)
    font4 = pygame.font.Font("7.ttf", 22)
    state=1
    while running:
        x+=1
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:  
                    if(state==1):
                        state=2
                        i=0
                        j=0
                        k=0
                        l=0
                        rendered_chars=""
                        rendered_chars1=""
                        rendered_chars2=""
                        rendered_chars3=""
                    elif(state==2):
                        state=3
                        i=0
                        j=0
                        k=0
                        l=0
                        rendered_chars=""
                        rendered_chars1=""
                        rendered_chars2=""
                        rendered_chars3=""
                    elif(state==3):
                        state=4
                        i=0
                        j=0
                        k=0
                        l=0
                        rendered_chars=""
                        rendered_chars1=""
                        rendered_chars2=""
                        rendered_chars3=""
                    elif(state==4):
                        return
        screen.blit(background_image, background_rect)
        # Draw background image
        print(x)
        if(x>500):
            # Draw dialog image
            if(state==1):
                screen.blit(dialog_image, dialog_rect)
                speech_text = "Welcome, " + name + ", to 'The Battle Within,'"
                i,rendered_chars=render_typing_text1(font4, speech_text, BLACK, (130, 100), screen,x,i,rendered_chars)
                speech_text2 = "a journey into the depths of the human psyche."
                if i==len(speech_text):
                    j,rendered_chars1=render_typing_text2(font4, speech_text2, BLACK, (130, 135), screen,x,j,rendered_chars1)
            elif(state==2):
                screen.blit(dialog_image2, dialog_rect2)
                speech_text = "As you step into this realm, you're entering a world where the mind's "
                i,rendered_chars=render_typing_text1(font5, speech_text, BLACK, (120, 90), screen,x,i,rendered_chars)
                speech_text2 = "mysteries unfold. Anxiety, depression, self-doubt — a few of the "
                if i==len(speech_text):
                    j,rendered_chars1=render_typing_text2(font5, speech_text2, BLACK, (120, 120), screen,x,j,rendered_chars1)
                speech_text3 = "adversaries you'll face along your path."
                if j==len(speech_text2):
                    k,rendered_chars2=render_typing_text3(font5, speech_text3, BLACK, (120, 150), screen,x,k,rendered_chars2)
            elif(state==3):
                screen.blit(dialog_image2, dialog_rect2)
                speech_text = "But fear not, for within you lies a strength untapped, a resilience "
                i,rendered_chars=render_typing_text1(font5, speech_text, BLACK, (120, 82), screen,x,i,rendered_chars)
                speech_text2 = "waiting to be discovered. Through your choices and actions, you'll "
                if i==len(speech_text):
                    j,rendered_chars1=render_typing_text2(font5, speech_text2, BLACK, (120, 107), screen,x,j,rendered_chars1)
                speech_text3 = "not only shape your own destiny but also shed light on the "
                if j==len(speech_text2):
                    k,rendered_chars2=render_typing_text3(font5, speech_text3, BLACK, (120, 132), screen,x,k,rendered_chars2)
                speech_text4 = "importance of mental health awareness."
                if k==len(speech_text3):
                    l,rendered_chars3=render_typing_text4(font5, speech_text4, BLACK, (120, 157), screen,x,l,rendered_chars3)
            elif(state==4):
                screen.blit(dialog_image2, dialog_rect2)
                speech_text = "Ready to embark on this quest? Before you begin, you must face "
                i,rendered_chars=render_typing_text1(font5, speech_text, BLACK, (120, 90), screen,x,i,rendered_chars)
                speech_text2 = "the first challenge: a question awaits you at the onset of  "
                if i==len(speech_text):
                    j,rendered_chars1=render_typing_text2(font5, speech_text2, BLACK, (120, 120), screen,x,j,rendered_chars1)
                speech_text3 = "your journey. Now let the journey begin."
                if j==len(speech_text2):
                    k,rendered_chars2=render_typing_text3(font5, speech_text3, BLACK, (120, 150), screen,x,k,rendered_chars2)


            
            

        # Update the display
        pygame.display.flip()

# second("Arnav")
# pygame.quit()
# sys.exit()

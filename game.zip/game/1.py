import pygame
import sys

# Initialize Pygame
pygame.init()

# Set up display
WIDTH, HEIGHT = 800, 600
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Mind Matters")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)

# Fonts
font = pygame.font.Font(None, 36)

# Game variables
emotional_meter = 0

# Main game loop
def main():
    global emotional_meter
    
    running = True
    while running:
        SCREEN.fill(WHITE)
        
        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        
        # Draw emotional meter
        draw_meter(emotional_meter)
        emotional_meter+=0.01
        emotional_meter=min(emotional_meter,100)
        # Update display
        pygame.display.flip()
        
    pygame.quit()
    sys.exit()

# Draw emotional meter
def draw_meter(value):
    pygame.draw.rect(SCREEN, BLACK, (50, 50, 300, 50), 2)  # Outline
    if value<50:
        pygame.draw.rect(SCREEN, BLUE, (52, 52, value * 3 - 4, 46))  # Fill
    else:
        pygame.draw.rect(SCREEN, BLUE, (52, 52, 50 * 3 - 4, 46)) 
        pygame.draw.rect(SCREEN, (255,0,0), (52+132, 52, (value) * 3 - 4-132, 46))

    text = font.render("Emotional Meter", True, BLACK)
    SCREEN.blit(text, (50, 20))

# Entry point
if __name__ == "__main__":
    main()

import pygame
import sys

# Initialize Pygame
# pygame.init()

def main():
    # Set up the screen

    pygame.mixer.music.load("main.mp3")
    pygame.mixer.music.play(loops=-1)  # Loop indefinitely

    screen_width = 930
    screen_height = 650
    screen = pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("The Battle Within")

    # Load background image
    background_image = pygame.image.load("back.png").convert()
    background_rect = background_image.get_rect()

    # Load additional image
    additional_image = pygame.image.load("name.png").convert_alpha()
    additional_image_rect = additional_image.get_rect()
    additional_image_rect.right = 950  # Set the right edge of the image to x-coordinate 1150
    additional_image_rect.top = 55     # Set the top edge of the image to y-coordinate 50

    # Load font
    font = pygame.font.Font("KNIGHT WARRIOR.otf", 50)


    # Define button positions
    start_button_pos = (615, 245)
    key_bindings_button_pos = (540, 345)
    exit_button_pos = (630, 445)

    # Define text colors
    initial_text_color = (0, 0, 0)  # Initial color of the text
    hovered_text_color = (139, 0, 0)  # Dark red color

    WHITE = (255, 255, 255)
    BLACK = (0, 0, 0)
    RED=(138,0,0)

    state = "menu"
    username_input = ""  # Initialize empty username string

    # Function to interpolate between two colors based on time parameter t
    def interpolate_color(color1, color2, t):
        r = int(color1[0] + (color2[0] - color1[0]) * t)
        g = int(color1[1] + (color2[1] - color1[1]) * t)
        b = int(color1[2] + (color2[2] - color1[2]) * t)
        return (r, g, b)

    # Function to check if mouse is hovering over a button
    def is_hovering(pos, button_rect):
        return button_rect.collidepoint(pos)

    # Main loop
    running = True
    while running:
        screen.blit(background_image, background_rect)  # Draw background image

        if state == "menu":
            screen.blit(additional_image, additional_image_rect)  # Draw additional image

            # Get mouse position
            mouse_pos = pygame.mouse.get_pos()

            # Check if mouse is hovering over each button
            start_button_hovered = is_hovering(mouse_pos, pygame.Rect(start_button_pos, (100, 50)))
            key_bindings_button_hovered = is_hovering(mouse_pos, pygame.Rect(key_bindings_button_pos, (200, 50)))
            exit_button_hovered = is_hovering(mouse_pos, pygame.Rect(exit_button_pos, (100, 50)))

            # Interpolate text colors based on hover status
            start_button_text_color = interpolate_color(initial_text_color, hovered_text_color, 0.5 if start_button_hovered else 0)
            key_bindings_button_text_color = interpolate_color(initial_text_color, hovered_text_color, 0.5 if key_bindings_button_hovered else 0)
            exit_button_text_color = interpolate_color(initial_text_color, hovered_text_color, 0.5 if exit_button_hovered else 0)

            # Render button texts
            start_button_text = font.render("Start", True, start_button_text_color)
            key_bindings_button_text = font.render("Key Bindings", True, key_bindings_button_text_color)
            exit_button_text = font.render("Exit", True, exit_button_text_color)

            # Blit button texts to screen
            screen.blit(start_button_text, start_button_pos)
            screen.blit(key_bindings_button_text, key_bindings_button_pos)
            screen.blit(exit_button_text, exit_button_pos)

        elif state == "key_bindings":
            key_bindings_font_size = 22
            key_bindings_font = pygame.font.Font("KNIGHT WARRIOR.otf", key_bindings_font_size)

            tb1 = pygame.Surface((360,80), pygame.SRCALPHA)
            tb1.fill((*BLACK,210))
            screen.blit(tb1, (60,100))

            t1 = "Arrow right                          Move right"
            tr1 = key_bindings_font.render(t1, True, WHITE)
            tt1 = tr1.get_rect(center=(240,140))
            screen.blit(tr1, tt1)

            tb2 = pygame.Surface((360,80), pygame.SRCALPHA)
            tb2.fill((*BLACK,210))
            screen.blit(tb2, (520,100))

            t2 = "Arrow left                             Move left"
            tr2 = key_bindings_font.render(t2, True, WHITE)
            tt2 = tr1.get_rect(center=(700,140))
            screen.blit(tr2, tt2)

            tb3 = pygame.Surface((360,80), pygame.SRCALPHA)
            tb3.fill((*BLACK,210))
            screen.blit(tb3, (60,230))

            t3 = "Arrow up                                         Jump"
            tr3 = key_bindings_font.render(t3, True, WHITE)
            tt3 = tr1.get_rect(center=(240,270))
            screen.blit(tr3, tt3)

            tb4 = pygame.Surface((360,80), pygame.SRCALPHA)
            tb4.fill((*BLACK,210))
            screen.blit(tb4, (520,230))

            t4 = "Arrow down                   Duck/BulletS"
            tr4 = key_bindings_font.render(t4, True, WHITE)
            tt4 = tr4.get_rect(center=(700,270))
            screen.blit(tr4, tt4)
            
            tb5 = pygame.Surface((360,80), pygame.SRCALPHA)
            tb5.fill((*BLACK,210))
            screen.blit(tb5, (290,360))

            t5 = "Space                    Ground Attack\Bullet"
            tr5 = key_bindings_font.render(t5, True, WHITE)
            tt5 = tr5.get_rect(center=(470,400))
            screen.blit(tr5, tt5)

        elif state == "enter_username":
            # Render username input field
            username_font_size = 45
            username_font = pygame.font.Font("KNIGHT WARRIOR.otf", username_font_size)
            
            # Render text prompting user to enter their username
            prompt_text = username_font.render("Enter your username:", True, BLACK)
            prompt_text_rect = prompt_text.get_rect(center=(screen_width // 2, screen_height // 2 - 50))
            screen.blit(prompt_text, prompt_text_rect)
            
            # Render the entered username so far
            username_text = username_font.render(username_input, True, RED)
            username_text_rect = username_text.get_rect(center=(screen_width // 2, screen_height // 2))
            screen.blit(username_text, username_text_rect)
            
        # Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if state == "menu":
                    # Handle button clicks
                    if is_hovering(pygame.mouse.get_pos(), pygame.Rect(start_button_pos, (100, 50))):
                        state = "enter_username"  # Switch to enter username state
                    elif is_hovering(pygame.mouse.get_pos(), pygame.Rect(key_bindings_button_pos, (200, 50))):
                        state = "key_bindings"
                    elif is_hovering(pygame.mouse.get_pos(), pygame.Rect(exit_button_pos, (100, 50))):
                        return
                elif state == "key_bindings":
                    state = "menu"  # Go back to menu when clicked anywhere on key bindings page
                elif state == "enter_username":
                    pass  # Allow user to enter username
            elif event.type == pygame.KEYDOWN:
                if state == "enter_username":
                    if event.key == pygame.K_RETURN:  # If Enter key is pressed
                        print("Entered username:", username_input)
                        return username_input
                    elif event.key == pygame.K_BACKSPACE:  # If Backspace key is pressed
                        username_input = username_input[:-1]  # Remove the last character from username
                    else:
                        username_input += event.unicode  # Append typed character to username

        pygame.display.flip()

# main()
# pygame.quit()
# sys.exit()

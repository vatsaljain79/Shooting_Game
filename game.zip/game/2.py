import pygame
import sys

# Initialize Pygame
from pygame.locals import *

pygame.init()
# flags = DOUBLEBUF | OPENGL  # Use hardware acceleration
# screen = pygame.display.set_mode((width, height), flags)

# Set up display
# WIDTH, HEIGHT = 800, 600
WIDTH, HEIGHT = 930,650
# OrI=pygame.display.set_mode((1000, 700))
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
# SCREEN=pygame.Surface((WIDTH, HEIGHT))
pygame.display.set_caption("Animated Character")
from Character import *
from LevelMaker import LevelMaker




FPS = 25  # Frames per second

# print(background.get_width(),'hi',background.get_height())
running = True
clock = pygame.time.Clock()
p=0
P1=Character(SCREEN,0,state='idle_right',WASD=True)
P2=Character(SCREEN,1000,state='idle_right',WASD=True)
P3=Character(SCREEN,200,state='idle_left',WASD=True)
# P4=Hobbit_with_Bullet(SCREEN,0,speed=20,name='P1',health=2000,player=True,bullet=True,bullet_speed=20,attack_freq=1)
P4=Hobbit(SCREEN,0,speed=20,name='P1',health=1000,player=True,attack_freq=1)
# P4=BOSS(SCREEN,0,speed=20,name='BOSS',health=1000,player=True,bullet=True,bullet_speed=20,attack_freq=1)
# P5=Hobbit(SCREEN,600,speed=5,WASD=True,name='P2',computer=P4)
P6=Hobbit(SCREEN,1200,speed=5,WASD=True,name='P3',computer=P4)
P7=Hobbit_with_Bullet(SCREEN,2100,speed=10,WASD=True,name='P2',computer=P4,bullet_speed=15,bullet=True)
P8=Hobbit_with_Bullet(SCREEN,1000,speed=10,WASD=True,name='P3',computer=P4,bullet_speed=15,bullet=True)
P9=BOSS(SCREEN,2300,speed=15,WASD=True,name='BOSS',computer=P4,health=2000,attack=80,attack_freq=1,bullet_speed=20,bullet=True)
P10=TeleBoss(SCREEN,2300,speed=0,WASD=True,name='TeleBoss',computer=P4,health=2000,attack=80,attack_freq=3,bullet_speed=20,bullet=True)
P11=DarkFairy(SCREEN,2300,speed=10,WASD=True,name='DarkFairy',computer=P4,health=2000,attack=100,attack_freq=3)
P12=Hobbit_with_Bullet(SCREEN,2300,speed=20,WASD=True,name='P2',health=2000,computer=P4,bullet_speed=15,bullet=True,summit=True,new_factor=100,attack_freq=1)
P13=MartialHero(SCREEN,2100,speed=10,WASD=True,name='P2',computer=P4)
P14=Final_Char(SCREEN,0,speed=15,name='BOSS',player=True,health=2000,attack=80,attack_freq=1,bullet_speed=20,bullet=True)
P15=Mushroom(SCREEN,1200,speed=7,WASD=True,name='P3',computer=P4,attack_freq=3)
P16=Skeleton(SCREEN,1500,speed=7,WASD=True,name='Skeleton',computer=P4,attack_freq=2,attack=40,health=500)
P17=Goblin(SCREEN,1800,speed=15,WASD=True,name='P3',computer=P4,attack_freq=1,bullet=True,bullet_speed=15)
P18=EyeMonster(SCREEN,1800,speed=7,WASD=True,name='P3',computer=P4,attack_freq=1)
P16.shield=True
# P4.offset-=38
# P12.offset-=68
# P4.canfloat=True
# background = pygame.image.load("forest.png")
# background1 = pygame.image.load("forest_text.png")
# player=Hobbit(SCREEN,0,speed=20,name='P1',health=1000,player=True,attack_freq=1)
# m1=Mushroom(SCREEN,700,speed=7,WASD=True,name='P3',computer=player,attack_freq=3,health=300)
# m2=Mushroom(SCREEN,1400,speed=7,WASD=True,name='P3',computer=player,attack_freq=3,health=300)
# g1=Goblin(SCREEN,1000,speed=10,WASD=True,name='P3',computer=player,attack_freq=1,bullet=True,bullet_speed=15)
# g2=Goblin(SCREEN,1500,speed=10,WASD=True,name='P3',computer=player,attack_freq=1,bullet=True,bullet_speed=15)
# boss=MartialHero(SCREEN,2300,speed=10,WASD=True,name='P2',computer=player,health=500)
# level1=LevelMaker(SCREEN,background,background1,[m1,m2,g1,g2,boss],player)
# level1.run()

# background = pygame.image.load("castle2.png")
# background1 = pygame.image.load("castle2_text.png")
# player=Hobbit_with_Bullet(SCREEN,0,speed=20,name='P1',health=2000,player=True,bullet=True,bullet_speed=20,attack_freq=1)
# m1=Mushroom(SCREEN,700,speed=10,WASD=True,name='P3',computer=player,attack_freq=3,health=300)
# m2=Mushroom(SCREEN,1400,speed=10,WASD=True,name='P3',computer=player,attack_freq=3,health=300)
# g1=Skeleton(SCREEN,1000,speed=15,WASD=True,name='Skeleton',computer=player,attack_freq=2,attack=40,health=500)
# g2=Skeleton(SCREEN,1500,speed=15,WASD=True,name='Skeleton',computer=player,attack_freq=2,attack=40,health=500)
# g1.shield=True
# g2.shield=True
# boss=BOSS(SCREEN,2300,speed=15,WASD=True,name='BOSS',computer=player,health=2000,attack=90,attack_freq=1,bullet_speed=20,bullet=True)
# for i in [m1,m2,g1,g2,boss,player]:
#     i.offset+=38
# level2=LevelMaker(SCREEN,background,background1,[m1,m2,g1,g2,boss],player)
# level2.run()

# background = pygame.image.load("labf.png")
# background1 = pygame.image.load("lab_textf.png")
# # player=Hobbit_with_Bullet(SCREEN,0,speed=20,name='P1',health=2500,player=True,bullet=True,bullet_speed=20,attack_freq=1)
# player=BOSS(SCREEN,0,speed=20,name='BOSS',health=2000,player=True,bullet=True,bullet_speed=20,attack_freq=1,bullet_attack=300)
# m1=EyeMonster(SCREEN,700,speed=10,WASD=True,name='P3',computer=player,attack_freq=1,health=300)
# m2=EyeMonster(SCREEN,1400,speed=10,WASD=True,name='P3',computer=player,attack_freq=1,health=300)
# g1=Skeleton(SCREEN,1000,speed=10,WASD=True,name='Skeleton',computer=player,attack_freq=2,attack=40,health=500)
# g2=Skeleton(SCREEN,1500,speed=15,WASD=True,name='Skeleton',computer=player,attack_freq=2,attack=40,health=500)
# g1.shield=True
# g2.shield=True
# boss=DarkFairy(SCREEN,2300,speed=10,WASD=True,name='DarkFairy',computer=player,health=2500,attack=100,attack_freq=3)
# for i in [m1,m2,g1,g2,boss,player]:
#     i.offset-=5
# level3=LevelMaker(SCREEN,background,background1,[m1,m2,g1,g2,boss],player)
# level3.run()

# background = pygame.image.load("summit.png")
# background1 = pygame.image.load("summit_text.png")
# # player=Hobbit_with_Bullet(SCREEN,0,speed=20,name='P1',health=2500,player=True,bullet=True,bullet_speed=20,attack_freq=1)
# player=BOSS(SCREEN,0,speed=20,name='BOSS',health=2000,player=True,bullet=True,bullet_speed=20,attack_freq=1,summit=True,attack=40)
# player.canfloat=True
# m1=EyeMonster(SCREEN,700,speed=10,WASD=True,name='P3',computer=player,attack_freq=1,health=300)
# m2=EyeMonster(SCREEN,1400,speed=10,WASD=True,name='P3',computer=player,attack_freq=1,health=300)
# # g1=Goblin(SCREEN,1000,speed=10,WASD=True,name='P3',computer=player,attack_freq=1,bullet=True,bullet_speed=15)
# g2=Goblin(SCREEN,1300,speed=10,WASD=True,name='P3',computer=player,attack_freq=1,bullet=True,bullet_speed=15)

# g2.shield=True
# boss=Hobbit_with_Bullet(SCREEN,2300,speed=20,WASD=True,name='bipolar',health=1500,computer=player,bullet_speed=15,bullet=True,summit=True,new_factor=100,attack_freq=1)
# for i in [m1,m2,g2,player]:
#     i.offset-=38
# boss.offset-=68
# level4=LevelMaker(SCREEN,background,background1,[m1,m2,g2,boss],player)
# level4.run()

# background = pygame.image.load("cave2_sym.png")
# background1 = pygame.image.load("cave2_sym1.png")
# # player=Hobbit_with_Bullet(SCREEN,0,speed=20,name='P1',health=2500,player=True,bullet=True,bullet_speed=20,attack_freq=1)
# player=DarkFairy(SCREEN,0,speed=20,name='DarkFairy',health=2000,attack=100,attack_freq=3,bullet_speed=20)
# boss=TeleBoss(SCREEN,2300,speed=0,WASD=True,name='TeleBoss',computer=player,health=2000,attack=80,attack_freq=3,bullet_speed=20,bullet=True)
# player.computer=boss
# player.player=True
# boss.offset+=30
# player.offset+=20
# level4=LevelMaker(SCREEN,background,background1,[boss],player)
# level4.run()









# # P1.speed=4
background_x=0
background_speed=20
# print(pygame.font.get_fonts())
while running:
    SCREEN.fill((255, 255, 255))
    SCREEN.blit(background,(background_x,0))
    SCREEN.blit(background,(background_x + WIDTH,0))
    SCREEN.blit(background,(background_x - WIDTH,0))
    text_surface = pygame.font.Font('freesansbold.ttf',50).render("H", True, (255,0,0))
    
    # Blit text surface onto screen
    # text_rect = text_surface.get_rect(center=(56, GROUND))  # Center text on screen
    # SCREEN.blit(text_surface, text_rect)
    # SCREEN.blit(P1.animation_frames2[0],(-40,HEIGHT//2 -70))
    P1.draw()
    
    # P2.draw()
    # if -128<P3.char_x<800:
    P3.draw()
    # if -128<P2.char_x<800:
    P2.draw()
    P4.draw()
    P5.draw()
    P6.draw()
    P7.draw()
    P8.draw()
    P9.draw()
    # SCREEN.blit(P7.bullet,(100,200))
    # P4.SCREEN.blit(P4.new_surface,(200,200))
    background_x,back_speed=P4.get_background(background_speed,background_x)
    # print(back_speed)
    if back_speed!=0: 
        P3.char_x-=back_speed; P2.char_x-=back_speed; P1.char_x-=back_speed 
        if True or P5.state!='left' and P5.state!='right':
            P5.char_x-=back_speed
        if True or P6.state!='left' and P6.state!='right':
            P6.char_x-=back_speed
        if True or P7.state!='left' and P7.state!='right':
            P7.char_x-=back_speed
            for bullet in P7.bullets:
                bullet.x-=back_speed
        if True or P7.state!='left' and P7.state!='right':
            P8.char_x-=back_speed
            for bullet in P8.bullets:
                bullet.x-=back_speed
        P9.char_x-=back_speed

    # P3.draw()
    # pygame.transform.scale(SCREEN, (1000, 700), OrI)
    pygame.display.flip()
    
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        # if event.type == pygame.KEYDOWN:
        #     if event.key == pygame.K_RIGHT:
        #         frame_count+=1
    
    
    # Animation control
    P4.frequency_manager(p,2,[P5,P6,P7,P8,P9])
    P5.frequency_manager(p,3,[P4])
    P6.frequency_manager(p,3,[P4])
    P7.frequency_manager(p,3,[P4])
    P8.frequency_manager(p,3,[P4])
    P9.frequency_manager(p,3,[P4])
    if p % 5==0:
        P1.frame_count1 += 1
        P2.frame_count1+=1
        P3.frame_count1+=1
        
    p+=1
    print(p)
    # print(P5.animation_frames7)
    clock.tick(FPS)

# Quit Pygame
pygame.quit()
sys.exit()
